<?php if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>
<main id="site-main" class="hoa-main hoa-page">
	<div class="hoa-container">
		<header class="hoa-page-header"><h1 class="hoa-page-title" data-amv3-stagger><?php the_title(); ?></h1></header>
		<article class="hoa-page-content"><?php while ( have_posts() ) : the_post(); the_content(); endwhile; ?></article>
	</div>
</main>
<?php get_footer();
