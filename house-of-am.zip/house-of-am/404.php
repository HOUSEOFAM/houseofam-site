<?php if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>
<main id="site-main" class="hoa-main hoa-404">
	<div class="hoa-container" style="text-align:center;padding:10vw 0;">
		<span class="hoa-eyebrow">Error 404</span>
		<h1 class="hoa-section-title" data-amv3-stagger>Off the map.</h1>
		<p class="hoa-muted">That page doesn't exist.</p>
		<p><a class="hoa-btn amv3-link" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></p>
	</div>
</main>
<?php get_footer();
