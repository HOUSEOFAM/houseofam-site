/* House of AM — V3 Effects Engine v3.1.0 */

(function(){
  'use strict';
  if(window.__AM_V3_EFFECTS_LOADED__) return;
  window.__AM_V3_EFFECTS_LOADED__=true;
  var root=document.documentElement,body=document.body;
  var abort=new AbortController();
  var lOpts={signal:abort.signal,passive:true},aOpts={signal:abort.signal};
  var mqReduce=window.matchMedia('(prefers-reduced-motion:reduce)');
  var mqCoarse=window.matchMedia('(pointer:coarse)');
  var reduced=function(){return mqReduce.matches};
  var coarse=function(){return mqCoarse.matches};

  // 1. PURGE legacy
  function purgeOld(){
    ['cursor-dot','cursor-ring','cursor','customCursor','am-cursor','am-cursor-dot','am-cursor-ring',
     'amv2-cursor-dot','amv2-cursor-ring','amv2-curtain','amv2-marquee','am-grain','amv2-grain']
    .forEach(function(id){
      var el=document.getElementById(id);
      if(el&&el.id.indexOf('amv3-')!==0){el.parentNode&&el.parentNode.removeChild(el)}
    });
    document.querySelectorAll('.cursor-dot,.cursor-ring,.am-cursor,.amv2-stagger-word').forEach(function(el){
      if(el.id&&el.id.indexOf('amv3-')===0) return;
      el.parentNode&&el.parentNode.removeChild(el);
    });
  }
  try{purgeOld()}catch(e){}

  // 2. CURSOR
  var dot=document.getElementById('amv3-cursor-dot');
  var ring=document.getElementById('amv3-cursor-ring');
  var customTextEl=ring&&ring.querySelector('.amv3-ring-custom');
  var mx=window.innerWidth/2,my=window.innerHeight/2,rx=mx,ry=my,rot=0;
  var rotSpeedTarget=0.35,rotSpeed=rotSpeedTarget;
  var cursorRunning=false,magnetTarget=null;

  function setCursorState(s,on){root.classList.toggle('amv3-'+s,!!on)}
  function tick(){
    if(!cursorRunning) return;
    if(dot) dot.style.transform='translate3d('+mx+'px,'+my+'px,0) translate(-50%,-50%)';
    rx+=(mx-rx)*0.16; ry+=(my-ry)*0.16;
    rotSpeed+=(rotSpeedTarget-rotSpeed)*0.08;
    rot=(rot+rotSpeed)%360;
    if(ring) ring.style.transform='translate3d('+rx+'px,'+ry+'px,0) translate(-50%,-50%) rotate('+rot+'deg)';
    requestAnimationFrame(tick);
  }
  function startCursor(){
    if(reduced()||coarse()||cursorRunning) return;
    cursorRunning=true; root.classList.add('amv3-ready'); requestAnimationFrame(tick);
  }
  function stopCursor(){
    cursorRunning=false;
    root.classList.remove('amv3-ready','amv3-hovering','amv3-active','amv3-text','amv3-custom','amv3-drag');
  }

  document.addEventListener('pointermove',function(e){
    if(e.pointerType==='touch') return;
    mx=e.clientX; my=e.clientY;
    if(magnetTarget){
      var r=magnetTarget.getBoundingClientRect();
      var dx=mx-(r.left+r.width/2),dy=my-(r.top+r.height/2);
      var str=parseFloat(magnetTarget.getAttribute('data-amv3-magnet'))||0.25;
      magnetTarget.style.setProperty('--amv3-mx',(dx*str)+'px');
      magnetTarget.style.setProperty('--amv3-my',(dy*str)+'px');
    }
  },lOpts);

  var HOVER_SEL='a,button,[data-nav],[role="button"],.door,.btn,.card,.door-card,.nav-link,.door-explore,input,select,textarea,label,summary';
  var TEXT_SEL='input[type="text"],input[type="email"],input[type="search"],input[type="tel"],input[type="password"],input[type="number"],input[type="url"],textarea,[contenteditable="true"],[data-cursor="text"]';
  function hoverMatch(el,sel){return el&&el.closest&&el.closest(sel)}

  function releaseMagnet(el){
    if(!el) return;
    el.classList.remove('amv3-magnet-active');
    el.style.removeProperty('--amv3-mx'); el.style.removeProperty('--amv3-my');
  }

  document.addEventListener('pointerover',function(e){
    if(reduced()||coarse()||e.pointerType==='touch') return;
    var t=e.target;
    setCursorState('text',!!hoverMatch(t,TEXT_SEL));
    setCursorState('drag',!!(t.closest&&t.closest('[draggable="true"],[data-cursor="drag"]')));
    var interactive=hoverMatch(t,HOVER_SEL);
    if(interactive){
      setCursorState('hovering',true); rotSpeedTarget=1.2;
      var withText=t.closest&&t.closest('[data-cursor-text]');
      if(withText&&customTextEl){customTextEl.textContent=withText.getAttribute('data-cursor-text');setCursorState('custom',true)}
      var magnet=t.closest&&t.closest('[data-amv3-magnet]');
      if(!magnet){magnet=interactive;if(!magnet.hasAttribute('data-amv3-magnet'))magnet.setAttribute('data-amv3-magnet','0.2')}
      if(magnet&&magnet!==magnetTarget){if(magnetTarget)releaseMagnet(magnetTarget);magnetTarget=magnet;magnet.classList.add('amv3-magnet-active')}
    }
  },aOpts);

  document.addEventListener('pointerout',function(e){
    if(reduced()||coarse()||e.pointerType==='touch') return;
    var t=e.target,rel=e.relatedTarget;
    if(hoverMatch(t,HOVER_SEL)&&!hoverMatch(rel,HOVER_SEL)){
      setCursorState('hovering',false);setCursorState('custom',false);setCursorState('drag',false);
      rotSpeedTarget=0.35;
      if(magnetTarget){releaseMagnet(magnetTarget);magnetTarget=null}
    }
  },aOpts);

  document.addEventListener('pointerdown',function(e){
    if(reduced()||coarse()||e.pointerType==='touch') return;
    setCursorState('active',true);
    var r=document.createElement('div');r.className='amv3-cursor-ripple';
    r.style.left=e.clientX+'px';r.style.top=e.clientY+'px';
    body.appendChild(r);setTimeout(function(){r.parentNode&&r.parentNode.removeChild(r)},650);
  },lOpts);
  document.addEventListener('pointerup',function(e){if(!reduced()&&!coarse()&&e.pointerType!=='touch')setCursorState('active',false)},lOpts);
  document.addEventListener('pointerleave',function(){if(dot)dot.style.opacity='0';if(ring)ring.style.opacity='0'},lOpts);
  document.addEventListener('pointerenter',function(){if(dot)dot.style.opacity='';if(ring)ring.style.opacity=''},lOpts);

  // 3. CURTAIN
  var curtainLock=false;
  var curtainEl=document.getElementById('amv3-curtain');
  function runCurtain(switchCb){
    if(curtainLock){try{switchCb&&switchCb()}catch(e){} return}
    if(reduced()){try{switchCb&&switchCb()}catch(e){} runStaggerOnActivePage();return}
    curtainLock=true;
    body.classList.remove('amv3-curtain-out');
    void curtainEl.offsetWidth;
    body.classList.add('amv3-curtain-in');
    var panels=curtainEl.querySelectorAll('.amv3-panel');
    var lastPanel=panels[panels.length-1];
    var handled=false;
    function onIn(e){
      if(e.target!==lastPanel||e.animationName!=='amv3-panel-in') return;
      if(handled) return; handled=true;
      lastPanel.removeEventListener('animationend',onIn);
      try{switchCb&&switchCb()}catch(err){console.warn('[AMv3] switch',err)}
      body.classList.remove('amv3-curtain-in');
      body.classList.add('amv3-curtain-out');
      var firstOut=panels[0];
      function onOut(ev){
        if(ev.target!==firstOut||ev.animationName!=='amv3-panel-out') return;
        firstOut.removeEventListener('animationend',onOut);
        body.classList.remove('amv3-curtain-out');
        curtainLock=false; runStaggerOnActivePage();
      }
      firstOut.addEventListener('animationend',onOut);
      setTimeout(function(){if(curtainLock){body.classList.remove('amv3-curtain-out');curtainLock=false}},2000);
    }
    lastPanel.addEventListener('animationend',onIn);
    setTimeout(function(){if(!handled)onIn({target:lastPanel,animationName:'amv3-panel-in'})},1000);
  }

  var WC_SKIP=['.ajax_add_to_cart','.single_add_to_cart_button','.add_to_cart_button','.checkout-button',
    '.wc-block-components-checkout-button','.wc-forward','.wc-block-cart__submit-button',
    '.woocommerce-Button','[data-no-transition]','[download]','form *',
    'a[href^="mailto:"]','a[href^="tel:"]','a[href^="#"]',
    'a[href*="wp-admin"]','a[href*="wp-login"]','a[href*="?add-to-cart"]','a[href*="&add-to-cart"]',
    '.no-amv3','.no-amv3 *'].join(',');
  function shouldSkip(link){
    if(!link||link.target==='_blank'||link.hasAttribute('download')) return true;
    try{if(link.matches(WC_SKIP)||link.closest(WC_SKIP)) return true}catch(e){}
    return false;
  }

  // SPA nav
  document.addEventListener('click',function(e){
    var link=e.target.closest&&e.target.closest('[data-nav]');
    if(!link||shouldSkip(link)) return;
    var pageName=link.getAttribute('data-nav');
    if(!pageName) return;
    e.preventDefault();
    runCurtain(function(){
      try{if(typeof window.showPage==='function'){window.showPage(pageName);return}}catch(err){}
      try{
        document.querySelectorAll('.page').forEach(function(p){p.classList.remove('active')});
        var target=document.getElementById('page-'+pageName);
        if(target){target.classList.add('active');window.scrollTo(0,0)}
      }catch(err){}
    });
  },aOpts);

  // WP page-to-page
  document.addEventListener('click',function(e){
    var link=e.target.closest&&e.target.closest('a.amv3-link,[data-amv3-link]');
    if(!link||shouldSkip(link)) return;
    var href=link.getAttribute('href');
    if(!href||href.charAt(0)==='#') return;
    try{var url=new URL(href,window.location.href);if(url.origin!==window.location.origin) return}catch(err){return}
    if(e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||e.button!==0) return;
    e.preventDefault();
    if(reduced()){window.location.href=link.href;return}
    body.classList.remove('amv3-curtain-out');
    void curtainEl.offsetWidth;
    body.classList.add('amv3-curtain-in');
    var panels=curtainEl.querySelectorAll('.amv3-panel');
    var last=panels[panels.length-1];
    var went=false;
    function go(){if(went)return;went=true;window.location.href=link.href}
    last.addEventListener('animationend',function h(ev){if(ev.animationName!=='amv3-panel-in')return;last.removeEventListener('animationend',h);go()});
    setTimeout(go,1100);
  },aOpts);

  // 4. WORD STAGGER
  var STAGGER_SEL='h1,h2.hero-heading,h2.page-hero-heading,.hero-title,.page-hero h1,.page-hero h2,[data-amv3-stagger]';
  function splitHeading(h){
    if(h.dataset.amv3Split) return;
    var walker=document.createTreeWalker(h,NodeFilter.SHOW_TEXT,null);
    var textNodes=[],n;
    while((n=walker.nextNode())){if(n.nodeValue&&n.nodeValue.trim())textNodes.push(n)}
    if(!textNodes.length){h.dataset.amv3Split='skip';return}
    var wordIndex=0;
    textNodes.forEach(function(node){
      var frag=document.createDocumentFragment();
      node.nodeValue.split(/(\s+)/).forEach(function(p){
        if(!p) return;
        if(/^\s+$/.test(p)){frag.appendChild(document.createTextNode(p));return}
        var wrap=document.createElement('span');wrap.className='amv3-stagger-wrap';
        var word=document.createElement('span');word.className='amv3-stagger-word';
        word.style.transitionDelay=(wordIndex*72)+'ms';word.textContent=p;
        wrap.appendChild(word);frag.appendChild(wrap);wordIndex++;
      });
      node.parentNode.replaceChild(frag,node);
    });
    h.dataset.amv3Split='1';
  }
  function prepareStaggerOn(scope){if(scope)scope.querySelectorAll(STAGGER_SEL).forEach(splitHeading)}
  function triggerStaggerInside(scope){
    if(!scope) return;
    var wraps=scope.querySelectorAll('.amv3-stagger-wrap');
    wraps.forEach(function(w){w.classList.remove('amv3-stagger-run')});
    requestAnimationFrame(function(){requestAnimationFrame(function(){wraps.forEach(function(w){w.classList.add('amv3-stagger-run')})})});
  }
  function runStaggerOnActivePage(){
    var active=document.querySelector('.page.active')||body;
    prepareStaggerOn(active);triggerStaggerInside(active);
  }
  function initStagger(){
    document.querySelectorAll('.page').forEach(prepareStaggerOn);
    if(!document.querySelector('.page'))prepareStaggerOn(body);
    runStaggerOnActivePage();
    if('IntersectionObserver' in window){
      var io=new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
          if(!entry.isIntersecting) return;
          prepareStaggerOn(entry.target.parentNode||entry.target);
          triggerStaggerInside(entry.target);
          io.unobserve(entry.target);
        });
      },{rootMargin:'0px 0px -10% 0px',threshold:0.1});
      document.querySelectorAll(STAGGER_SEL).forEach(function(h){io.observe(h)});
    }
  }

  // 5. MARQUEE
  function buildMarquee(){
    if(document.getElementById('amv3-marquee')) return;
    var anchor=null;
    ['#page-home .four-doors','#page-home .manifesto','#page-home #four-doors','.four-doors','.manifesto','footer']
    .some(function(s){anchor=document.querySelector(s);return !!anchor});
    if(!anchor) return;
    var mq=document.createElement('div');mq.id='amv3-marquee';mq.setAttribute('aria-hidden','true');
    var r1=['Precision Grooming','Recovery Redefined','Premium Products','Identity Over Image','Built To The Standard','Not Routine','AM Barber Lounge','AM Rénovaïr','AM Essence','AM Attire'];
    var r2=['329 High Road · Harrow','Hijama · Dry Cupping · Compression','Members Only · Locked Pricing','Deluxe Facial · Facial · Express','Standard Over Volume','Premium Without Apology','Built To Last','Identity Over Image'];
    function row(cls,items){
      var r=document.createElement('div');r.className='amv3-mq-row '+cls;
      r.innerHTML=items.concat(items).map(function(t){return '<span class="amv3-mq-item">'+t+'<span class="amv3-mq-sep"> ✦ </span></span>'}).join('');
      return r;
    }
    mq.appendChild(row('r1',r1));mq.appendChild(row('r2',r2));
    anchor.parentNode.insertBefore(mq,anchor);
  }

  // 6. SCROLL PROGRESS
  var progressEl=document.getElementById('amv3-scroll-progress'),progressRAF=null;
  function onScroll(){
    if(progressRAF) return;
    progressRAF=requestAnimationFrame(function(){
      progressRAF=null;if(!progressEl) return;
      var h=document.documentElement;
      var pct=Math.max(0,Math.min(1,(h.scrollTop||body.scrollTop)/((h.scrollHeight-h.clientHeight)||1)));
      progressEl.style.transform='scaleX('+pct+')';
    });
  }
  window.addEventListener('scroll',onScroll,lOpts);

  // 7. FILM GRAIN
  function buildGrain(){
    if(reduced()||document.getElementById('amv3-grain')) return;
    var svg='<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch"/><feColorMatrix values="0 0 0 0 1  0 0 0 0 .92  0 0 0 0 .68  0 0 0 .55 0"/></filter><rect width="100%" height="100%" filter="url(#n)"/></svg>';
    var g=document.createElement('div');g.id='amv3-grain';g.setAttribute('aria-hidden','true');
    g.style.backgroundImage='url("data:image/svg+xml;utf8,'+encodeURIComponent(svg)+'")';
    body.appendChild(g);
    var last=0;
    (function shift(ts){
      if(!document.getElementById('amv3-grain')) return;
      if(!document.hidden&&ts-last>80){last=ts;g.style.backgroundPosition=((Math.random()*20)|0)+'px '+((Math.random()*20)|0)+'px'}
      requestAnimationFrame(shift);
    })(0);
  }

  // 8. TAB VISIBILITY
  document.addEventListener('visibilitychange',function(){root.classList.toggle('amv3-hidden',document.hidden)},lOpts);

  // 9. FPS WATCHDOG
  function fpsWatchdog(){
    if(reduced()||coarse()) return;
    var frames=0,start=performance.now(),strikes=0;
    (function sample(){
      frames++;
      var elapsed=performance.now()-start;
      if(elapsed>=1000){
        var fps=(frames*1000)/elapsed;
        if(fps<40)strikes++;else strikes=Math.max(0,strikes-1);
        if(strikes>=3&&!root.classList.contains('amv3-lite')){root.classList.add('amv3-lite');return}
        frames=0;start=performance.now();
      }
      requestAnimationFrame(sample);
    })();
  }

  // 10. MQ CHANGES
  function onMQChange(){if(reduced()||coarse())stopCursor();else startCursor()}
  try{mqReduce.addEventListener('change',onMQChange)}catch(e){mqReduce.addListener&&mqReduce.addListener(onMQChange)}
  try{mqCoarse.addEventListener('change',onMQChange)}catch(e){mqCoarse.addListener&&mqCoarse.addListener(onMQChange)}

  // 11. PAGE OBSERVER
  function initPageObserver(){
    if(!('MutationObserver' in window)) return;
    var pages=document.querySelectorAll('.page');if(!pages.length) return;
    var lastId=null;
    var mo=new MutationObserver(function(){
      var a=document.querySelector('.page.active');
      if(a&&a.id!==lastId){lastId=a.id;if(!curtainLock)runStaggerOnActivePage()}
    });
    pages.forEach(function(p){mo.observe(p,{attributes:true,attributeFilter:['class']})});
  }

  // 12. ENTRANCE
  function playEntrance(){
    if(reduced()) return;
    try{var nav=performance.getEntriesByType&&performance.getEntriesByType('navigation')[0];if(nav&&nav.type==='back_forward') return}catch(e){}
    body.classList.add('amv3-curtain-out');
    var panels=curtainEl.querySelectorAll('.amv3-panel');
    var first=panels[0];
    function done(ev){if(ev&&ev.animationName!=='amv3-panel-out') return;first.removeEventListener('animationend',done);body.classList.remove('amv3-curtain-out');runStaggerOnActivePage()}
    first.addEventListener('animationend',done);
    setTimeout(function(){done({animationName:'amv3-panel-out'})},800);
    // Hard fallback: force panels off screen after 1s no matter what
    setTimeout(function(){
      body.classList.remove('amv3-curtain-out');
      if(curtainEl){
        curtainEl.querySelectorAll('.amv3-panel').forEach(function(p){
          p.style.transform='translate3d(110%,0,0)';
          p.style.animation='none';
        });
        curtainEl.style.pointerEvents='none';
      }
    }, 1000);
  }

  // BOOT
  function boot(){
    try{purgeOld()}catch(e){}
    try{buildMarquee()}catch(e){console.warn('[AMv3] marquee',e)}
    try{initStagger()}catch(e){console.warn('[AMv3] stagger',e)}
    try{initPageObserver()}catch(e){}
    try{playEntrance()}catch(e){}
    var idle=window.requestIdleCallback||function(cb){setTimeout(cb,1)};
    idle(function(){try{buildGrain()}catch(e){}try{fpsWatchdog()}catch(e){}});
    startCursor();onScroll();
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',boot,{once:true})}else{boot()}

  window.AMv3={
    version:'3.1.0',
    runCurtain:runCurtain,runStagger:runStaggerOnActivePage,entrance:playEntrance,
    lite:function(on){root.classList.toggle('amv3-lite',on!==false)},
    destroy:function(){
      try{abort.abort()}catch(e){}
      stopCursor();
      ['amv3-curtain','amv3-cursor-dot','amv3-cursor-ring','amv3-scroll-progress','amv3-marquee','amv3-grain']
      .forEach(function(id){var el=document.getElementById(id);el&&el.parentNode&&el.parentNode.removeChild(el)});
      var css=document.getElementById('am-v3-effects-css');css&&css.parentNode&&css.parentNode.removeChild(css);
      root.classList.remove('amv3-ready','amv3-hovering','amv3-active','amv3-text','amv3-custom','amv3-drag','amv3-hidden','amv3-lite');
      delete window.__AM_V3_EFFECTS_LOADED__;delete window.AMv3;
    }
  };
})();
