<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function hoa_customize_register( $wp_customize ) {
	$wp_customize->add_panel( 'hoa_panel', array( 'title' => __( 'House of AM — Content', 'house-of-am' ), 'priority' => 30 ) );

	// Hero
	$wp_customize->add_section( 'hoa_hero', array( 'title' => __( 'Hero', 'house-of-am' ), 'panel' => 'hoa_panel' ) );
	$hero_fields = array(
		'hero_eyebrow'  => array( 'label' => 'Eyebrow',       'default' => 'House of AM' ),
		'hero_title'    => array( 'label' => 'Main title',    'default' => 'Not Routine.' ),
		'hero_tagline'  => array( 'label' => 'Tagline',       'default' => 'Precision grooming · Recovery redefined · Premium products · Identity over image.' ),
		'hero_cta_text' => array( 'label' => 'CTA text',      'default' => 'Book a chair' ),
		'hero_cta_url'  => array( 'label' => 'CTA URL',       'default' => '/book/' ),
	);
	foreach ( $hero_fields as $key => $meta ) {
		$wp_customize->add_setting( 'hoa_' . $key, array( 'default' => $meta['default'], 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp_customize->add_control( 'hoa_' . $key, array( 'label' => $meta['label'], 'section' => 'hoa_hero', 'type' => 'text' ) );
	}

	// Manifesto
	$wp_customize->add_section( 'hoa_manifesto', array( 'title' => __( 'Manifesto', 'house-of-am' ), 'panel' => 'hoa_panel' ) );
	$wp_customize->add_setting( 'hoa_manifesto_eyebrow', array( 'default' => 'The Standard', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'hoa_manifesto_eyebrow', array( 'label' => 'Eyebrow', 'section' => 'hoa_manifesto', 'type' => 'text' ) );
	$wp_customize->add_setting( 'hoa_manifesto_title', array( 'default' => 'Built for identity. Not for image.', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'hoa_manifesto_title', array( 'label' => 'Title', 'section' => 'hoa_manifesto', 'type' => 'text' ) );
	$wp_customize->add_setting( 'hoa_manifesto_body', array( 'default' => 'Every service, every product, every detail is chosen to raise the standard — not to follow it. You are not routine. You are a signature.', 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'hoa_manifesto_body', array( 'label' => 'Body copy', 'section' => 'hoa_manifesto', 'type' => 'textarea' ) );

	// Four Doors
	$wp_customize->add_section( 'hoa_doors', array( 'title' => __( 'Four Doors URLs', 'house-of-am' ), 'panel' => 'hoa_panel' ) );
	foreach ( array( 'barber' => 'AM Barber Lounge', 'renovair' => 'AM Rénovaïr', 'essence' => 'AM Essence', 'attire' => 'AM Attire' ) as $slug => $label ) {
		$wp_customize->add_setting( 'hoa_door_' . $slug . '_url', array( 'default' => '#', 'sanitize_callback' => 'esc_url_raw' ) );
		$wp_customize->add_control( 'hoa_door_' . $slug . '_url', array( 'label' => $label . ' URL', 'section' => 'hoa_doors', 'type' => 'url' ) );
	}

	// Location
	$wp_customize->add_section( 'hoa_location', array( 'title' => __( 'Location & Contact', 'house-of-am' ), 'panel' => 'hoa_panel' ) );
	$loc_fields = array(
		'loc_address' => array( 'label' => 'Address', 'default' => '329 High Road, Harrow HA3 5EQ' ),
		'loc_phone'   => array( 'label' => 'Phone',   'default' => '020 8378 9463' ),
		'loc_email'   => array( 'label' => 'Email',   'default' => 'info@ambarberlounge.co.uk' ),
		'loc_hours'   => array( 'label' => 'Hours',   'default' => 'Tue–Sun · By appointment' ),
		'loc_insta'   => array( 'label' => 'Instagram URL', 'default' => '' ),
	);
	foreach ( $loc_fields as $key => $meta ) {
		$wp_customize->add_setting( 'hoa_' . $key, array( 'default' => $meta['default'], 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp_customize->add_control( 'hoa_' . $key, array( 'label' => $meta['label'], 'section' => 'hoa_location', 'type' => 'text' ) );
	}
}
add_action( 'customize_register', 'hoa_customize_register' );
