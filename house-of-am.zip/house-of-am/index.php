<?php if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>
<main id="site-main" class="hoa-main hoa-page">
	<div class="hoa-container">
		<?php if ( have_posts() ) : ?>
			<div class="hoa-posts">
				<?php while ( have_posts() ) : the_post(); ?>
					<article <?php post_class( 'hoa-post-card' ); ?>>
						<h2 class="hoa-post-title"><a class="amv3-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<div class="hoa-post-excerpt"><?php the_excerpt(); ?></div>
					</article>
				<?php endwhile; ?>
			</div>
			<div class="hoa-pagination"><?php the_posts_pagination(); ?></div>
		<?php else : ?>
			<p><?php esc_html_e( 'Nothing here yet.', 'house-of-am' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php get_footer();
