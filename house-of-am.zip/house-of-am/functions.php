<?php
if ( ! defined( 'ABSPATH' ) ) exit;
define( 'HOA_VERSION', '1.0.2' );
define( 'HOA_DIR', get_template_directory() );
define( 'HOA_URI', get_template_directory_uri() );

function hoa_setup() {
	load_theme_textdomain( 'house-of-am', HOA_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 240, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'house-of-am' ),
		'footer'  => __( 'Footer Menu', 'house-of-am' ),
	) );
}
add_action( 'after_setup_theme', 'hoa_setup' );

function hoa_enqueue() {
	wp_enqueue_style( 'hoa-fonts',
		'https://fonts.googleapis.com/css2?family=Archivo+Black&family=Playfair+Display:ital,wght@0,400;0,600;1,400;1,600&display=swap',
		array(), null );
	wp_enqueue_style( 'hoa-theme', HOA_URI . '/assets/css/theme.css', array(), HOA_VERSION );
	wp_enqueue_style( 'hoa-style', get_stylesheet_uri(), array( 'hoa-theme' ), HOA_VERSION );
	wp_enqueue_script( 'hoa-amv3', HOA_URI . '/assets/js/amv3.js', array(), HOA_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'hoa_enqueue' );

function hoa_widgets() {
	register_sidebar( array(
		'name'          => __( 'Footer', 'house-of-am' ),
		'id'            => 'footer-1',
		'before_widget' => '<section id="%1$s" class="hoa-widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="hoa-widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'hoa_widgets' );

require_once HOA_DIR . '/inc/customizer.php';

function hoa_get( $key, $default = '' ) {
	return get_theme_mod( 'hoa_' . $key, $default );
}

function hoa_body_class( $classes ) {
	$classes[] = 'hoa';
	if ( is_front_page() ) $classes[] = 'hoa-front';
	return $classes;
}
add_filter( 'body_class', 'hoa_body_class' );

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content',  'woocommerce_output_content_wrapper_end', 10 );
add_action( 'woocommerce_before_main_content', function () {
	echo '<main id="site-main" class="hoa-main hoa-shop-wrap"><div class="hoa-container">';
} );
add_action( 'woocommerce_after_main_content', function () {
	echo '</div></main>';
} );
add_filter( 'woocommerce_show_page_title', '__return_false' );

function hoa_door( $key, $title, $tagline, $url = '#', $cta = 'Enter' ) { ?>
	<a class="hoa-door amv3-link" href="<?php echo esc_url( $url ); ?>" data-cursor-text="<?php echo esc_attr( strtoupper( $cta ) ); ?>" data-amv3-tilt="6">
		<div class="hoa-door-inner">
			<span class="hoa-door-eyebrow"><?php echo esc_html( $key ); ?></span>
			<h3 class="hoa-door-title" data-amv3-stagger><?php echo esc_html( $title ); ?></h3>
			<p class="hoa-door-tagline"><?php echo esc_html( $tagline ); ?></p>
			<span class="hoa-door-cta"><?php echo esc_html( $cta ); ?> &nbsp;→</span>
		</div>
	</a>
<?php }

function hoa_skip_link() {
	echo '<a class="skip-link screen-reader-text" href="#site-main">' . esc_html__( 'Skip to content', 'house-of-am' ) . '</a>';
}
add_action( 'wp_body_open', 'hoa_skip_link' );
