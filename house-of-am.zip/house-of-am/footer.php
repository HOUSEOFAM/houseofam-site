<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<footer class="hoa-site-footer" id="site-footer">
	<div class="hoa-container hoa-footer-grid">
		<div class="hoa-footer-col hoa-footer-brand">
			<div class="hoa-brand-mark hoa-mark-big">AM</div>
			<div class="hoa-brand-sub">HOUSE OF AM</div>
			<p class="hoa-footer-line"><?php echo esc_html( hoa_get( 'loc_address', '329 High Road, Harrow HA3 5EQ' ) ); ?></p>
			<p class="hoa-footer-line hoa-muted"><?php echo esc_html( hoa_get( 'loc_hours', 'Tue–Sun · By appointment' ) ); ?></p>
		</div>
		<div class="hoa-footer-col">
			<h4 class="hoa-footer-title">Contact</h4>
			<?php $email = hoa_get( 'loc_email' ); if ( $email ) : ?>
				<a class="hoa-footer-link" href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
			<?php endif; ?>
			<?php $phone = hoa_get( 'loc_phone' ); if ( $phone ) : ?>
				<a class="hoa-footer-link" href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a>
			<?php endif; ?>
			<?php $insta = hoa_get( 'loc_insta' ); if ( $insta ) : ?>
				<a class="hoa-footer-link" href="<?php echo esc_url( $insta ); ?>" target="_blank" rel="noopener">Instagram</a>
			<?php endif; ?>
		</div>
		<div class="hoa-footer-col">
			<h4 class="hoa-footer-title">Navigate</h4>
			<?php if ( has_nav_menu( 'footer' ) ) :
				wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'menu_class' => 'hoa-footer-menu', 'depth' => 1, 'fallback_cb' => false ) );
			elseif ( is_active_sidebar( 'footer-1' ) ) :
				dynamic_sidebar( 'footer-1' );
			else : ?>
				<ul class="hoa-footer-menu">
					<li><a class="amv3-link" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
					<?php if ( class_exists( 'WooCommerce' ) ) : ?>
					<li><a class="amv3-link" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">Shop</a></li>
					<?php endif; ?>
				</ul>
			<?php endif; ?>
		</div>
	</div>
	<div class="hoa-footer-baseline">
		<div class="hoa-container">
			<p>© <?php echo date( 'Y' ); ?> House of AM. All rights reserved.</p>
		</div>
	</div>
</footer>

<!-- V3 EFFECTS DOM -->
<div id="amv3-curtain" aria-hidden="true">
	<div class="amv3-panel p1"></div><div class="amv3-panel p2"></div><div class="amv3-panel p3"></div>
	<div class="amv3-slash"></div>
	<div class="amv3-mark"><div class="amv3-mark-letters">AM</div><div class="amv3-mark-sub">HOUSE OF AM</div></div>
</div>
<div id="amv3-cursor-ring" aria-hidden="true">
	<svg viewBox="0 0 112 112">
		<defs><path id="amv3-ring-path" d="M 56,56 m -44,0 a 44,44 0 1,1 88,0 a 44,44 0 1,1 -88,0"/></defs>
		<circle class="amv3-ring-circle" cx="56" cy="56" r="54"/>
		<text class="amv3-ring-text"><textPath href="#amv3-ring-path" startOffset="0">EXPERIENCE · HOUSE OF AM · EXPERIENCE · HOUSE OF AM ·</textPath></text>
		<text class="amv3-ring-custom" x="56" y="60"></text>
	</svg>
</div>
<div id="amv3-cursor-dot" aria-hidden="true"></div>
<div id="amv3-scroll-progress" aria-hidden="true"></div>

<?php wp_footer(); ?>
</body>
</html>
