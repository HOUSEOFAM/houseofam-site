<?php if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>
<main id="site-main" class="hoa-main hoa-page">
	<div class="hoa-container hoa-single">
		<?php while ( have_posts() ) : the_post(); ?>
			<header class="hoa-page-header"><h1 class="hoa-page-title" data-amv3-stagger><?php the_title(); ?></h1></header>
			<article <?php post_class( 'hoa-page-content' ); ?>><?php the_content(); ?></article>
		<?php endwhile; ?>
	</div>
</main>
<?php get_footer();
