<?php if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<main id="site-main" class="hoa-main">

	<section class="hoa-hero">
		<div class="hoa-container hoa-hero-inner">
			<span class="hoa-eyebrow"><?php echo esc_html( hoa_get( 'hero_eyebrow', 'House of AM' ) ); ?></span>
			<h1 class="hoa-hero-title" data-amv3-stagger><?php echo esc_html( hoa_get( 'hero_title', 'Not Routine.' ) ); ?></h1>
			<p class="hoa-hero-tagline"><?php echo esc_html( hoa_get( 'hero_tagline', 'Precision grooming · Recovery redefined · Premium products · Identity over image.' ) ); ?></p>
			<a class="hoa-btn hoa-btn-primary amv3-link" href="<?php echo esc_url( hoa_get( 'hero_cta_url', '/book/' ) ); ?>" data-cursor-text="BOOK" data-amv3-magnet="0.25">
				<?php echo esc_html( hoa_get( 'hero_cta_text', 'Book a chair' ) ); ?> <span aria-hidden="true">→</span>
			</a>
		</div>
		<div class="hoa-hero-glow" aria-hidden="true"></div>
	</section>

	<section class="hoa-manifesto">
		<div class="hoa-container">
			<span class="hoa-eyebrow"><?php echo esc_html( hoa_get( 'manifesto_eyebrow', 'The Standard' ) ); ?></span>
			<h2 class="hoa-section-title" data-amv3-stagger><?php echo esc_html( hoa_get( 'manifesto_title', 'Built for identity. Not for image.' ) ); ?></h2>
			<p class="hoa-manifesto-body"><?php echo esc_html( hoa_get( 'manifesto_body', 'Every service, every product, every detail is chosen to raise the standard — not to follow it. You are not routine. You are a signature.' ) ); ?></p>
		</div>
	</section>

	<section class="hoa-doors" id="four-doors">
		<div class="hoa-container">
			<span class="hoa-eyebrow">The House</span>
			<h2 class="hoa-section-title" data-amv3-stagger>Four Doors. One Standard.</h2>
			<div class="hoa-doors-grid four-doors">
				<?php
				hoa_door( '01', 'AM Barber Lounge', 'Precision grooming, cuts, beards, and the classics — sharpened.', hoa_get( 'door_barber_url', '#' ), 'Book' );
				hoa_door( '02', 'AM Rénovaïr', 'Recovery redefined — hijama, dry cupping, compression, facials.', hoa_get( 'door_renovair_url', '#' ), 'Recover' );
				hoa_door( '03', 'AM Essence', 'Premium products built to the standard, not the shelf.', hoa_get( 'door_essence_url', '#' ), 'Shop' );
				hoa_door( '04', 'AM Attire', 'Wear identity. Not trend.', hoa_get( 'door_attire_url', '#' ), 'Wear' );
				?>
			</div>
		</div>
	</section>

	<section class="hoa-location">
		<div class="hoa-container hoa-location-inner">
			<span class="hoa-eyebrow">Visit</span>
			<h2 class="hoa-section-title hoa-location-title" data-amv3-stagger><?php echo esc_html( hoa_get( 'loc_address', '329 High Road, Harrow HA3 5EQ' ) ); ?></h2>
			<p class="hoa-muted"><?php echo esc_html( hoa_get( 'loc_hours', 'Tue–Sun · By appointment' ) ); ?></p>
			<div class="hoa-location-ctas">
				<?php if ( $email = hoa_get( 'loc_email' ) ) : ?>
					<a class="hoa-btn" href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
				<?php endif; ?>
				<?php if ( $phone = hoa_get( 'loc_phone' ) ) : ?>
					<a class="hoa-btn hoa-btn-ghost" href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $phone ) ); ?>">Call</a>
				<?php endif; ?>
			</div>
		</div>
	</section>

</main>

<?php get_footer();
