<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0f0d0a">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="hoa-site-header" id="site-header">
	<div class="hoa-container hoa-header-inner">
		<div class="hoa-brand">
			<?php if ( has_custom_logo() ) : the_custom_logo();
			else : ?>
				<a class="hoa-brand-text amv3-link" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<span class="hoa-brand-mark">AM</span>
					<span class="hoa-brand-name">House of AM</span>
				</a>
			<?php endif; ?>
		</div>
		<nav class="hoa-nav" aria-label="Primary">
			<?php if ( has_nav_menu( 'primary' ) ) :
				wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'hoa-menu', 'depth' => 2, 'fallback_cb' => false ) );
			else : ?>
				<ul class="hoa-menu">
					<li><a class="amv3-link" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
					<?php if ( class_exists( 'WooCommerce' ) ) : ?>
					<li><a class="amv3-link" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">Shop</a></li>
					<li><a class="amv3-link" href="<?php echo esc_url( wc_get_cart_url() ); ?>" data-cursor-text="BAG">Bag</a></li>
					<?php endif; ?>
				</ul>
			<?php endif; ?>
		</nav>
	</div>
</header>
