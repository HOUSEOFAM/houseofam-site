<?php
/**
 * House of AM — header.php
 * Preserved from commit 16c8bc5a
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta http-equiv="X-Content-Type-Options" content="nosniff">
<meta name="referrer" content="strict-origin-when-cross-origin">
<meta name="color-scheme" content="dark light">
<meta name="theme-color" content="#1a1714">
<meta name="format-detection" content="telephone=no">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>


<!-- LOADER -->
<div class="loader" id="loader">
<svg class="loader-mark" viewbox="200 130 1520 680" xmlns="http://www.w3.org/2000/svg">
<defs>
<lineargradient gradientunits="userSpaceOnUse" id="eA" x1="963" x2="956" y1="167" y2="737"><stop offset="0" stop-color="#C8C8C8"></stop><stop offset="1" stop-color="#909090"></stop></lineargradient>
<lineargradient gradientunits="userSpaceOnUse" id="eB" x1="694" x2="1225" y1="632" y2="632"><stop offset="0" stop-color="#DDC18E"></stop><stop offset="1" stop-color="#B1915D"></stop></lineargradient>
</defs>
<polygon fill="url(#eA)" points="960,260 1033,463 1109,463 1083,390 998,156 960,156 959,156 921,156 836,390 810,463 886,463"></polygon>
<polygon fill="url(#eB)" points="1118,485 1117,484 1041,484 1041,485 960,675 878,485 878,484 802,484 801,485 694,780 771,780 843,580 929,780 959,780 960,780 990,780 1076,580 1148,780 1225,780"></polygon>
</svg>
<div class="loader-bar-track"><div class="loader-bar"></div></div>
<div class="loader-sub">House of AM</div>
</div>
<!-- PAGE TRANSITION -->
<div class="page-transition" id="pageTransition">
<svg class="transition-mark" viewbox="200 130 1520 680" xmlns="http://www.w3.org/2000/svg">
<defs>
<lineargradient gradientunits="userSpaceOnUse" id="tA" x1="963" x2="956" y1="167" y2="737"><stop offset="0" stop-color="#C8C8C8"></stop><stop offset="1" stop-color="#909090"></stop></lineargradient>
<lineargradient gradientunits="userSpaceOnUse" id="tB" x1="694" x2="1225" y1="632" y2="632"><stop offset="0" stop-color="#DDC18E"></stop><stop offset="1" stop-color="#B1915D"></stop></lineargradient>
</defs>
<polygon fill="url(#tA)" points="960,260 1033,463 1109,463 1083,390 998,156 960,156 959,156 921,156 836,390 810,463 886,463"></polygon>
<polygon fill="url(#tB)" points="1118,485 1117,484 1041,484 1041,485 960,675 878,485 878,484 802,484 801,485 694,780 771,780 843,580 929,780 959,780 960,780 990,780 1076,580 1148,780 1225,780"></polygon>
</svg>
<div class="transition-bar-track"><div class="transition-bar" id="transitionBar"></div></div>
</div>
<!-- HEADER -->

<header class="site-header" id="siteHeader">
<div class="logo-lockup" data-nav="home">
<svg class="nav-logo-mark" viewbox="200 130 1520 680" xmlns="http://www.w3.org/2000/svg">
<defs>
<lineargradient gradientunits="userSpaceOnUse" id="nA" x1="963" x2="956" y1="167" y2="737"><stop offset="0" stop-color="#C8C8C8"></stop><stop offset="1" stop-color="#808080"></stop></lineargradient>
<lineargradient gradientunits="userSpaceOnUse" id="nB" x1="694" x2="1225" y1="632" y2="632"><stop offset="0" stop-color="#DDC18E"></stop><stop offset="1" stop-color="#B1915D"></stop></lineargradient>
</defs>
<polygon fill="url(#nA)" points="960,260 1033,463 1109,463 1083,390 998,156 960,156 959,156 921,156 836,390 810,463 886,463"></polygon>
<polygon fill="url(#nB)" points="1118,485 1117,484 1041,484 1041,485 960,675 878,485 878,484 802,484 801,485 694,780 771,780 843,580 929,780 959,780 960,780 990,780 1076,580 1148,780 1225,780"></polygon>
</svg>
<div class="nav-wordmark">
<span class="nav-brand-line"></span>
<span class="nav-house">House of AM</span>
<span class="nav-brand-line"></span>
</div>
</div>
<nav id="primaryNav">
<button aria-expanded="false" aria-label="Menu" class="menu-toggle" id="menuToggle">
<span class="menu-toggle-bar"></span>
</button>
<ul class="nav-links" id="navList">
<li><a class="active" data-nav="home">Home</a></li>
<li><span class="nav-sep"></span></li>
<li><a data-nav="about">About</a></li>
<li><span class="nav-sep"></span></li>
<li><a data-nav="barber-lounge">Barber Lounge</a></li>
<li><span class="nav-sep"></span></li>
<li><a data-nav="renovair">Rénovaïr</a></li>
<li><span class="nav-sep"></span></li>
<li><a data-nav="essence">Essence</a></li>
<li><span class="nav-sep"></span></li>
<li><a data-nav="attire">Attire</a></li>
</ul>
</nav>
</header>