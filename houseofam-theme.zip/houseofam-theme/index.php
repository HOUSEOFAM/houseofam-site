<?php
/**
 * House of AM — index.php
 * Preserved from commit 16c8bc5a
 * All pages, SPA routing, animations intact
 */
get_header();
?>


<!-- ═══ HOME ═══ -->
<div class="page active" id="page-home">
<section class="hero">
<span class="bracket bracket-tl"></span><span class="bracket bracket-tr"></span>
<span class="bracket bracket-bl"></span><span class="bracket bracket-br"></span>
<div class="hero-content">
<svg class="hero-mark" viewbox="200 130 1520 680" xmlns="http://www.w3.org/2000/svg">
<defs>
<lineargradient gradientunits="userSpaceOnUse" id="hA" x1="963" x2="956" y1="167" y2="737"><stop offset="0" stop-color="#D8D8D8"></stop><stop offset="1" stop-color="#909090"></stop></lineargradient>
<lineargradient gradientunits="userSpaceOnUse" id="hB" x1="694" x2="1225" y1="632" y2="632"><stop offset="0" stop-color="#DDC18E"></stop><stop offset="1" stop-color="#B1915D"></stop></lineargradient>
</defs>
<polygon fill="url(#hA)" points="960,260 1033,463 1109,463 1083,390 998,156 960,156 959,156 921,156 836,390 810,463 886,463"></polygon>
<polygon fill="url(#hB)" points="1118,485 1117,484 1041,484 1041,485 960,675 878,485 878,484 802,484 801,485 694,780 771,780 843,580 929,780 959,780 960,780 990,780 1076,580 1148,780 1225,780"></polygon>
</svg>
<span class="vline-drop"></span>
<p class="house-of-am-text">House of AM</p>
<span class="bottom-rule"></span>
<h1 class="hero-h1" id="heroH1" style="opacity:0;transform:translateY(20px);transition:opacity .9s ease .3s,transform .9s cubic-bezier(.23,1,.32,1) .3s">For Those Who Expect More.<br/>Not A Destination.<br/><em>A Standard.</em></h1>
<p class="hero-sub">Precision Grooming<span class="dot">·</span>Recovery<span class="dot">·</span>Products<span class="dot">·</span>Identity</p>
<div class="hero-cta-wrap">
<button class="btn-gold" data-nav="barber-lounge">Enter The House</button>
<div class="membership-closed">
<span class="closed-rule"></span>
<span class="closed-text">Membership · Lock Your Rate · Closed</span>
<span class="closed-rule"></span>
</div>
</div>
</div>
<div class="hero-scroll">Scroll<span class="scroll-line"></span></div>
</section>
<section class="manifesto" id="about">
<div class="manifesto-eyebrow reveal">The House</div>
<h2>This Is Not Built For Everyone.</h2>
<h2>Most Move Without Direction. They Follow. They Repeat. Some Don't.</h2>
<hr class="manifesto-divider"/>
<h2>They Refine How They Present Themselves. They Take Control Of How They Operate. They Invest In How They Feel.</h2>
<h2><em>Not Occasionally. Consistently.</em></h2>
<hr class="manifesto-divider"/>
<div class="manifesto-close">
<h3>The House Exists For Those Who Choose Differently.</h3>
<p>Defined By Standards. Not Routine.</p>
</div>
</section>
<section class="pillars">
<div class="inner">
<div>
<span class="pillars-label">The Philosophy</span>
<h2 class="pillars-title">Four Pillars. <em>One Standard.</em></h2>
</div>
<div class="pillar-list">
<div class="pillar reveal"><div class="pillar-num">01</div><div><span class="pillar-accent"></span><p class="pillar-principle">Standard Over Volume</p><span class="pillar-brand">AM Barber Lounge</span><p class="pillar-lead">We Turn Away Before We Compromise.</p><p>A Full Book At The Right Standard Is Worth More Than A Full Building At The Wrong One. This Is Not Arrogance. It Is Architecture.</p></div></div>
<div class="pillar reveal"><div class="pillar-num">02</div><div><span class="pillar-accent"></span><p class="pillar-principle">Premium Without Apology</p><span class="pillar-brand">AM Essence</span><p class="pillar-lead">Every Decision Passes One Filter.</p><p>Does It Increase The Standard Or Dilute It? No Middle Ground.</p></div></div>
<div class="pillar reveal"><div class="pillar-num">03</div><div><span class="pillar-accent"></span><p class="pillar-principle">Built To Last</p><span class="pillar-brand">AM Rénovaïr</span><p class="pillar-lead">Performance Fades When Recovery Is Ignored.</p><p>Weight, Permanence, Results That Outlast Any Movement.</p></div></div>
<div class="pillar reveal"><div class="pillar-num">04</div><div><span class="pillar-accent"></span><p class="pillar-principle">Identity Over Image</p><span class="pillar-brand">AM Attire</span><p class="pillar-lead">Not Merch. Not Fashion For Fashion's Sake.</p><p>For The Man Who Doesn't Dress To Be Seen, But Because He Knows Exactly Who He Is.</p></div></div>
</div>
</div>
</section>
<section class="doors-section">
<div class="doors-head">
<div class="doors-eyebrow">House of AM</div>
<h2>Four Doors. <em>One Standard.</em></h2>
</div>
<div class="doors-grid">
<div class="door"><div class="door-logo">
<svg data-name="Layer 1" id="bld-layer" style="height:130px;width:auto;display:block;margin:0 auto" viewbox="0 0 1395.21 808.23" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
<lineargradient gradienttransform="translate(0 998.96) scale(1 -1)" gradientunits="userSpaceOnUse" id="bld-linear-gradient" x1="701.4" x2="694.1" y1="987.56" y2="418.56">
<stop offset="0" stop-color="#b3b3b3"></stop>
<stop offset="1" stop-color="gray"></stop>
</lineargradient>
</defs>
<polygon class="bld-cls-4" points="697.6 104.43 771.22 307 847.4 307 821.09 234.59 735.85 0 698.37 0 696.84 0 659.37 0 574.13 234.59 547.82 307 624 307 697.6 104.43"></polygon>
<polygon class="bld-cls-3" points="855.86 328.86 855.55 328 779.19 328 779.53 328.94 697.61 519.16 615.68 328.94 616.02 328 539.67 328 539.36 328.86 432.11 624 508.46 624 581.17 423.87 667.32 624 696.84 624 698.37 624 727.89 624 814.05 423.87 886.76 624 963.1 624 855.86 328.86"></polygon>
<g class="bld-cls-2">
<text class="bld-cls-1" transform="translate(.13 770.73)"><tspan class="bld-cls-5" x="0" y="0">B</tspan><tspan x="106.54" xml:space="preserve" y="0">ARBER  </tspan><tspan class="bld-cls-5" x="736.54" y="0">L</tspan><tspan x="827.54" y="0">OUNGE</tspan></text>
<text></text>
</g>
</svg>
</div><div class="door-content"><div class="door-discipline">Precision Grooming</div><h3 class="door-heading didot">BARBER LOUNGE</h3><div class="door-rule"></div><p class="door-tagline">Where precision meets ritual. Not a barbershop — a standard. Every visit, every time.</p><button class="door-cta" data-nav="barber-lounge">Explore</button></div></div>
<div class="door"><div class="door-logo"><img alt="AM Rénovaïr" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2aWV3Qm94PSIwIDAgNTg0LjMgNTM4LjciPgogIDxkZWZzPgogICAgPHN0eWxlPgogICAgICAuY2xzLTEgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTcpOwogICAgICB9CgogICAgICAuY2xzLTIgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTUpOwogICAgICB9CgogICAgICAuY2xzLTMgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTYpOwogICAgICB9CgogICAgICAuY2xzLTQgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTQpOwogICAgICB9CgogICAgICAuY2xzLTUgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTMpOwogICAgICB9CgogICAgICAuY2xzLTYgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTIpOwogICAgICB9CgogICAgICAuY2xzLTcgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50KTsKICAgICAgfQoKICAgICAgLmNscy04IHsKICAgICAgICBmaWxsOiAjYjM5ODcwOwogICAgICB9CiAgICA8L3N0eWxlPgogICAgPGxpbmVhckdyYWRpZW50IGlkPSJsaW5lYXItZ3JhZGllbnQiIHgxPSIxOTQuNjYiIHkxPSI0MDcuMTUiIHgyPSIzODUuNDQiIHkyPSI0MDcuMTUiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA3MjcuODYpIHNjYWxlKDEgLTEpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2RkYzE4ZSIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiMTkxNWQiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICA8bGluZWFyR3JhZGllbnQgaWQ9ImxpbmVhci1ncmFkaWVudC0yIiB4MT0iMTQ3Ljk2IiB5MT0iNTY1Ljc5IiB4Mj0iMjY3LjIyIiB5Mj0iNTY1Ljc5IiBncmFkaWVudFRyYW5zZm9ybT0idHJhbnNsYXRlKDAgNzI3Ljg2KSBzY2FsZSgxIC0xKSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNkZGMxOGUiLz4KICAgICAgPHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjYjE5MTVkIi8+CiAgICA8L2xpbmVhckdyYWRpZW50PgogICAgPGxpbmVhckdyYWRpZW50IGlkPSJsaW5lYXItZ3JhZGllbnQtMyIgeDE9IjMxMy4wMyIgeTE9IjU2NS44IiB4Mj0iNDMyLjI5IiB5Mj0iNTY1LjgiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA3MjcuODYpIHNjYWxlKDEgLTEpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2RkYzE4ZSIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiMTkxNWQiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICA8bGluZWFyR3JhZGllbnQgaWQ9ImxpbmVhci1ncmFkaWVudC00IiB4MT0iMjMxLjA0IiB5MT0iNjM4LjM2IiB4Mj0iMzQ5LjIzIiB5Mj0iNjM4LjM2IiBncmFkaWVudFRyYW5zZm9ybT0idHJhbnNsYXRlKDAgNzI3Ljg2KSBzY2FsZSgxIC0xKSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNiM2IzYjMiLz4KICAgICAgPHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSJncmF5Ii8+CiAgICA8L2xpbmVhckdyYWRpZW50PgogICAgPGxpbmVhckdyYWRpZW50IGlkPSJsaW5lYXItZ3JhZGllbnQtNSIgeDE9IjE2MC43MiIgeTE9IjUwOS43OCIgeDI9IjQxOS41NSIgeTI9IjUwOS43OCIgZ3JhZGllbnRUcmFuc2Zvcm09InRyYW5zbGF0ZSgwIDcyNy44Nikgc2NhbGUoMSAtMSkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgICAgPHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjZGRjMThlIi8+CiAgICAgIDxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI2IxOTE1ZCIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0ibGluZWFyLWdyYWRpZW50LTYiIHgxPSIxODQuNTQiIHkxPSI0MzIuNDQiIHgyPSIzOTUuNzIiIHkyPSI0MzIuNDQiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA3MjcuODYpIHNjYWxlKDEgLTEpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2RkYzE4ZSIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiMTkxNWQiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICA8bGluZWFyR3JhZGllbnQgaWQ9ImxpbmVhci1ncmFkaWVudC03IiB4MT0iOTEuODIiIHkxPSI1MjkuNTQiIHgyPSI0ODguNDUiIHkyPSI1MjkuNTQiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA3MjcuODYpIHNjYWxlKDEgLTEpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2RkYzE4ZSIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiMTkxNWQiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgPC9kZWZzPgogIDxnPgogICAgPGc+CiAgICAgIDxwYXRoIGNsYXNzPSJjbHMtNyIgZD0iTTM3OC44NywzMDIuMDdjLTEuMDgtLjI2LTIuMTItLjUtMy4xNi0uNzQtMS44LDEuNS0zLjY1LDIuOTUtNS41Miw0LjM2LTcuMjUtMS40MS0xNC40Ny0yLjM4LTIxLjY0LTIuNjYtMTEuNzgtLjQ2LTIyLjYzLDMuNC0zMy4xMSw3LjE1LTUuOTIsMi4xMS0xMi4wNSw0LjI5LTE4LjEyLDUuNTctMTMuOTYsMi45Ni0yNi4yOC0xLjQ0LTM5LjM1LTYuMDgtMy4xNi0xLjEzLTYuNDQtMi4zLTkuNzgtMy4zNy0xMy4xMy00LjI1LTI2LjA2LTMuNjYtMzguNzctMS4xMi0xLjgzLTEuMzctMy42MS0yLjc5LTUuMzUtNC4yNS0uOTUuMjQtMS45NC41LTIuOTIuNzYtMi4yLjYxLTQuNDEsMS4yNi02LjQ5LDEuODcsMS41MSwxLjM3LDMuMDQsMi43MSw0LjYyLDQuMDMsMi42NiwyLjIxLDUuNDEsNC4zMyw4LjIzLDYuMzYsMjMuMywxNi42OSw1MS44NSwyNi41NCw4Mi42MywyNi41NHM1OC44MS05LjY2LDgyLTI2LjA4YzIuODgtMi4wNSw1LjctNC4yMSw4LjQzLTYuNDUsMS42NS0xLjM2LDMuMjgtMi43OCw0Ljg3LTQuMjEtMi4yNi0uNjEtNC40Ni0xLjE2LTYuNTYtMS42N2gtLjAxWk0yOTAuMTMsMzMyLjNjLTI2LjAzLDAtNTAuMzctNy40Ni03MC45OC0yMC4zOCw4Ljk5LTEuMDMsMTgtLjY3LDI2Ljg4LDIuMjEsMy4yNCwxLjA0LDYuNDYsMi4yLDkuNTgsMy4zLDE0LjAyLDUsMjcuMjUsOS43Myw0My4xNCw2LjM2LDYuNTMtMS4zOCwxMi44OC0zLjY1LDE5LjAyLTUuODUsMTAuMzEtMy42NywyMC4wNC03LjE1LDMwLjQ4LTYuNzMsNC4wMi4xNCw4LjA4LjU0LDEyLjE1LDEuMTItMjAuNDUsMTIuNjUtNDQuNTQsMTkuOTYtNzAuMjksMTkuOTZoLjAyWiIvPgogICAgICA8cGF0aCBjbGFzcz0iY2xzLTYiIGQ9Ik0yNjcuMjIsNTguMDJsLTQuNDksOS4xNWMtNjAuNzcsMTIuNjctMTA2LjU4LDY2LjY2LTEwNi41OCwxMzEuMTYsMCwyMS4wMSw0Ljg2LDQwLjkxLDEzLjUzLDU4LjY0bC0xLjUsMy4wMy0yLjk5LDYuMTFjLTEwLjk5LTIwLjE2LTE3LjIzLTQzLjI2LTE3LjIzLTY3Ljc4LDAtNzAuNTksNTEuNzItMTI5LjMzLDExOS4yNi0xNDAuMzFoMFoiLz4KICAgICAgPHBhdGggY2xhc3M9ImNscy01IiBkPSJNNDMyLjI5LDE5OC4zMmMwLDI0LjUxLTYuMjQsNDcuNjItMTcuMjMsNjcuNzhsLTIuOTktNi4xMS0xLjQ5LTMuMDRjOC42OC0xNy43MiwxMy41Mi0zNy42MSwxMy41Mi01OC42MywwLTY0LjUtNDUuOC0xMTguNDktMTA2LjU4LTEzMS4xNmwtMS40OS0zLjA1LTMtNi4xYzY3LjU0LDEwLjk4LDExOS4yNiw2OS43MSwxMTkuMjYsMTQwLjMxaDBaIi8+CiAgICAgIDxwb2x5Z29uIGNsYXNzPSJjbHMtNCIgcG9pbnRzPSIzNDkuMjMgMTQyLjEzIDMxNy44MyAxNDIuMTMgMjkwLjEzIDg1LjYyIDI2Mi40MyAxNDIuMTMgMjMxLjA0IDE0Mi4xMyAyMzEuNzEgMTQwLjc2IDIzMS43MSAxNDAuNzUgMjY4LjMxIDY2LjExIDI3Mi42NyA1Ny4yMyAyNzcuMTkgNDguMDIgMjgyLjY1IDM2Ljg2IDI5Ny42MSAzNi44NiAzMDMuMDcgNDguMDIgMzA3LjU5IDU3LjIzIDMxMS45NCA2Ni4xMSAzNDguNTQgMTQwLjc1IDM0OC41NCAxNDAuNzYgMzQ5LjIzIDE0Mi4xMyIvPgogICAgICA8cG9seWdvbiBjbGFzcz0iY2xzLTIiIHBvaW50cz0iNDE5LjU1IDI4NS41NyAzODguMTUgMjg1LjU3IDMzOS45MiAxODcuMTggMzM2Ljg4IDE4MSAzMDguNzcgMjM4LjMzIDMwNS43MyAyNDQuNTMgMjk4LjI4IDI1OS43NCAyODEuOTggMjU5Ljc0IDI3NC41MyAyNDQuNTMgMjcxLjUgMjM4LjMzIDI0My4zOCAxODEgMjQwLjM1IDE4Ny4xOCAxOTIuMTEgMjg1LjU3IDE2MC43MiAyODUuNTcgMTY3LjkyIDI3MC44OCAxNzIuMjggMjYxLjk5IDIyNC42NCAxNTUuMTcgMjI2Ljg5IDE1MC41OCAyNTkuODcgMTUwLjU4IDI4Ny4xOSAyMDYuMzEgMjkwLjEzIDIxMi4zMiAyOTMuMDYgMjA2LjMxIDMyMC4zOCAxNTAuNTggMzUzLjM2IDE1MC41OCAzNTUuNjEgMTU1LjE3IDQwNy45OSAyNjEuOTkgNDEyLjM1IDI3MC44OCA0MTkuNTUgMjg1LjU3Ii8+CiAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0iTTM5NS43MiwyOTMuNDJjLTIuMDcsMi4yOS00LjIsNC41Mi02LjQxLDYuNjYtMy4xMi0uODYtNi4yNC0xLjY3LTkuMzYtMi40NC0xMC42Ni0yLjYxLTIxLjMyLTQuNTctMzEuNjgtNC45Ni0xMC40NC0uNDItMjAuMTcsMy4wNS0zMC40OSw2LjczLTYuMTIsMi4yLTEyLjQ4LDQuNDYtMTkuMDEsNS44NS0xNS44OCwzLjM3LTI5LjEyLTEuMzYtNDMuMTQtNi4zNS0zLjEyLTEuMTItNi4zNS0yLjI2LTkuNTgtMy4zMi0xNS4yNS00LjkyLTMwLjc4LTIuNDktNDYuMTEsMS43Mi0zLjA0LjgzLTYuMDgsMS43NC05LjExLDIuNjUtMi4xNi0yLjEyLTQuMjUtNC4zMS02LjI5LTYuNTYsMi45LS45LDUuNzktMS43OSw4LjctMi42NSwxNy44OC01LjI4LDM2LjIzLTkuMDYsNTQuOTUtMywzLjM0LDEuMDcsNi42MiwyLjI0LDkuNzgsMy4zNywxMy4wNiw0LjY2LDI1LjQsOS4wNCwzOS4zNSw2LjEsNi4wNy0xLjI5LDEyLjE5LTMuNDgsMTguMTItNS41OCwxMC40OC0zLjc0LDIxLjMzLTcuNjEsMzMuMTEtNy4xNSwxMi42NC41LDI1LjUsMy4xNSwzOC4yNiw2LjQ5LDIuOTguNzgsNS45NSwxLjU5LDguOTEsMi40NGgwWiIvPgogICAgPC9nPgogICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMjkwLjEzLDBDMTgwLjc4LDAsOTEuODIsODguOTcsOTEuODIsMTk4LjMyczg4Ljk2LDE5OC4zMSwxOTguMzEsMTk4LjMxLDE5OC4zMi04OC45NiwxOTguMzItMTk4LjMxUzM5OS40OCwwLDI5MC4xMywwWk0yOTAuMTMsNS45MWwuMDcuMTQtLjE4LjA4LjExLS4yMlpNMjkwLjEzLDM3Ny45MWMtOTkuMDQsMC0xNzkuNTktODAuNTYtMTc5LjU5LTE3OS41OSwwLTU0LjMsMjUuMjktMTA2LjUxLDY3LjctMTQwLjM5LDQ4LjgzLTM4Ljk5LDExNi43LTQ5Ljc4LDE3NS4xNi0yNy43MSw0OS43LDE4Ljc2LDg5LjQ2LDU5Ljc1LDEwNi42OSwxMTAsNi4zOSwxOC42OCw5LjY0LDM4LjM3LDkuNjQsNTguMTEsMCw5OS4wMi04MC41NiwxNzkuNTktMTc5LjYsMTc5LjU5aDBaIi8+CiAgPC9nPgogIDxnPgogICAgPHBhdGggY2xhc3M9ImNscy04IiBkPSJNNjAuMSw1MzYuOXYuNmMtMS42LjItNi42LjQtOS42LjQtNy4yLDAtOS0zLjItMjEuNC0zMC40LTEuNy0zLjYtMy40LTQuNC02LjYtNC40aC00LjF2MjEuNGMwLDcuNC40LDEyLjQsNy4yLDEyLjR2LjZIMHYtLjZjNi44LDAsNy4yLTUsNy4yLTEyLjR2LTQ2LjhjMC03LjQtLjQtMTIuNC03LjItMTIuNHYtLjZoMjdjMTYsMCwyNC44LDcuNCwyNC44LDE5LDAsOS44LTcuMywxNi0xNi4zLDE4LjR2LjJjMi45LDEuNyw1LjQsNS43LDcuOCwxMC4zLDEwLDE5LjIsMTIsMjIuNywxNi44LDI0LjNaTTE4LjQsNTAxLjVoNi44YzkuOSwwLDE1LTYuMSwxNS0xN3MtNC43LTE4LjItMTQuOS0xOC4yaC0zLjFjLTIuNCwwLTMuOCwxLjItMy44LDMuNnYzMS42WiIvPgogICAgPHBhdGggY2xhc3M9ImNscy04IiBkPSJNMTMzLjUsNTE5LjhsLTIuNCwxNy43aC01MS4zdi0uNmM2LjgsMCw3LjItNSw3LjItMTIuNHYtNDYuOGMwLTcuNC0uNC0xMi40LTcuMi0xMi40di0uNmg0OS44bDEuMywxNS44aC0uNmMtNS41LTExLjctOS4yLTE0LjItMjAuMi0xNC4yaC0xMS45djMyLjVoOS4xYzkuMywwLDExLjctMi41LDEzLjctOS45aC42djIyLjJoLS42Yy0yLTcuNC00LjQtMTAuNy0xMy43LTEwLjdoLTkuMXYzMC44YzAsMywuOSw0LjcsNCw0LjdoOS4zYzEwLjQsMCwxNS0yLjIsMjEuNC0xNi4xaC42Wk0xMDMuMiw0NTkuM2wtLjQtLjJjMi42LTYsNi4yLTE3LjUsNy41LTE5LjYuOS0xLjQsMi4yLTIuMiwzLjYtMi4yLDIuNiwwLDQuNCwyLjQsNC40LDQuMywwLC44LS4zLDEuNi0uOCwyLjQtMS4zLDIuMS0xMCwxMC4zLTE0LjMsMTUuM1oiLz4KICAgIDxwYXRoIGNsYXNzPSJjbHMtOCIgZD0iTTE5OS40LDQ2NC43aDE4Ljh2LjZjLTYuOCwwLTcuOCw3LjYtNy44LDE4LjR2NTVoLS42bC00My42LTY1LjN2NDUuM2MwLDEwLjQsMiwxOC4yLDkuMiwxOC4ydi42aC0xOS44di0uNmM2LjgsMCw4LjgtNy44LDguOC0xOC4ydi00Mi40YzAtNy4yLTMuNC0xMC4yLTguOC0xMXYtLjZoMThsMzUsNTIuOXYtMzMuOWMwLTEwLjgtMS42LTE4LjQtOS4yLTE4LjR2LS42WiIvPgogICAgPHBhdGggY2xhc3M9ImNscy04IiBkPSJNMjQwLjMsNTAxLjNjMC0yMi40LDEzLjItMzcuOCwzMy0zNy44czMyLjgsMTQuNiwzMi44LDM3LjQtMTMuMiwzNy44LTMzLDM3LjgtMzIuOC0xNC42LTMyLjgtMzcuNFpNMjkzLjcsNTAxLjFjMC0yMC4yLTctMzYuMi0yMC42LTM2LjJzLTIwLjQsMTUuNC0yMC40LDM2LjIsNywzNi4yLDIwLjYsMzYuMiwyMC40LTE1LjQsMjAuNC0zNi4yWiIvPgogICAgPHBhdGggY2xhc3M9ImNscy04IiBkPSJNMzcwLDQ2NC43aDE2Ljh2LjZjLTQuOC44LTcuMyw3LjMtMTEuNiwxOS4zbC0xOS41LDU0LjFoLS44bC0yMi02MS4yYy0yLjktOC4yLTQuOS0xMS44LTkuMS0xMi4ydi0uNmgyNS42di42Yy01LjYuNC03LjUsMy43LTUuNSw5LjVsMTYuMiw0Ni4zLDEzLjItMzcuMWM0LjItMTEuOCwzLjUtMTcuOS0zLjMtMTguN3YtLjZaIi8+CiAgICA8cGF0aCBjbGFzcz0iY2xzLTgiIGQ9Ik00NDUuNSw1MjQuN2MyLjksOC4yLDQuOSwxMS44LDkuMSwxMi4ydi42aC0yNS42di0uNmM1LjYtLjQsNy41LTQuMiw1LjYtOS41bC01LjItMTQuN2gtMjIuM2wtMiw1LjVjLTQuMiwxMS44LTMuNSwxNy45LDMuMywxOC43di42aC0xNi44di0uNmM0LjgtLjYsNy4zLTcuMywxMS42LTE5LjNsMTkuNS01NC4xaC44bDIyLDYxLjJaTTQwNy45LDUxMC4zaDIwLjdsLTEwLjMtMjkuMi0xMC40LDI5LjJaIi8+CiAgICA8cGF0aCBjbGFzcz0iY2xzLTgiIGQ9Ik00ODguMSw0MzguN2wxNS41LDIwLjEtLjMuNS0xNS41LTEwLjktMTUuNSwxMC45LS4zLS41LDE1LjUtMjAuMWguNlpNNDc1LDQ2NC43aDI1LjZ2LjZjLTYuOCwwLTcuMiw1LTcuMiwxMi40djQ2LjhjMCw3LjQuNCwxMi40LDcuMiwxMi40di42aC0yNS42di0uNmM2LjgsMCw3LjItNSw3LjItMTIuNHYtNDYuOGMwLTcuNC0uNC0xMi40LTcuMi0xMi40di0uNloiLz4KICAgIDxwYXRoIGNsYXNzPSJjbHMtOCIgZD0iTTU4NC4zLDUzNi45di42Yy0xLjYuMi02LjYuNC05LjYuNC03LjIsMC05LTMuMi0yMS40LTMwLjQtMS43LTMuNi0zLjQtNC40LTYuNi00LjRoLTQuMXYyMS40YzAsNy40LjQsMTIuNCw3LjIsMTIuNHYuNmgtMjUuNnYtLjZjNi44LDAsNy4yLTUsNy4yLTEyLjR2LTQ2LjhjMC03LjQtLjQtMTIuNC03LjItMTIuNHYtLjZoMjdjMTYsMCwyNC44LDcuNCwyNC44LDE5LDAsOS44LTcuMywxNi0xNi4zLDE4LjR2LjJjMi45LDEuNyw1LjQsNS43LDcuOCwxMC4zLDEwLDE5LjIsMTIsMjIuNywxNi44LDI0LjNaTTU0Mi42LDUwMS41aDYuOGM5LjksMCwxNS02LjEsMTUtMTdzLTQuNy0xOC4yLTE0LjktMTguMmgtMy4xYy0yLjQsMC0zLjgsMS4yLTMuOCwzLjZ2MzEuNloiLz4KICA8L2c+Cjwvc3ZnPg=="/></div><div class="door-content"><div class="door-discipline">Recovery</div><h3 class="door-heading didot">RÉNOVAÎR</h3><div class="door-rule"></div><p class="door-tagline">Performance fades when recovery is ignored. Built to restore the man behind the standard.</p><button class="door-cta" data-nav="renovair">Explore</button></div></div>
<div class="door"><div class="door-logo">
<svg data-name="Layer 1" id="essd-layer" style="height:130px;width:auto;display:block;margin:0 auto" viewbox="0 0 772.79 780.42" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
<lineargradient gradienttransform="translate(0 899) scale(1 -1)" gradientunits="userSpaceOnUse" id="essd-linear-gradient" x1="390.19" x2="382.89" y1="887.59" y2="317.92">
<stop offset="0" stop-color="#b3b3b3"></stop>
<stop offset="1" stop-color="gray"></stop>
</lineargradient>
</defs>
<polygon class="essd-cls-1" points="386.39 104.55 460.09 307.36 536.36 307.36 510.02 234.87 424.68 0 387.16 0 385.63 0 348.11 0 262.77 234.87 236.43 307.36 312.7 307.36 386.39 104.55"></polygon>
<polygon class="essd-cls-4" points="544.49 329.72 544.18 328.86 467.9 328.86 468.24 329.8 386.4 519.83 304.55 329.8 304.89 328.86 228.61 328.86 228.3 329.72 121.16 624.57 197.43 624.57 270.07 424.64 356.14 624.57 385.63 624.57 387.16 624.57 416.65 624.57 502.72 424.64 575.36 624.57 651.63 624.57 544.49 329.72"></polygon>
<g class="essd-cls-3">
<g class="essd-cls-3">
<path class="essd-cls-4" d="M73.18,760.86v13.86H5v-99.4h66.92v13.86H20.68v28.28h44.38v13.02H20.68v30.38h52.5Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-2" d="M73.18,760.86v13.86H5v-99.4h66.92v13.86H20.68v28.28h44.38v13.02H20.68v30.38h52.5Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-4" d="M174.58,698.7c-.93-1.03-2.29-2.12-4.06-3.29-1.77-1.17-3.87-2.26-6.3-3.29-2.43-1.03-5.04-1.87-7.84-2.52-2.8-.65-5.69-.98-8.68-.98-6.53,0-11.39,1.21-14.56,3.63-3.17,2.42-4.76,5.77-4.76,10.05,0,3.16.89,5.65,2.66,7.47,1.77,1.82,4.48,3.33,8.12,4.54,3.64,1.21,8.21,2.51,13.72,3.91,6.72,1.58,12.55,3.47,17.5,5.65,4.95,2.19,8.73,5.09,11.34,8.72,2.61,3.63,3.92,8.42,3.92,14.37,0,5.03-.93,9.35-2.8,12.98-1.87,3.63-4.48,6.58-7.84,8.86s-7.23,3.96-11.62,5.02c-4.39,1.07-9.1,1.6-14.14,1.6s-9.87-.51-14.77-1.54c-4.9-1.03-9.57-2.54-14-4.55-4.43-2.01-8.52-4.46-12.25-7.35l7.14-13.44c1.21,1.21,2.96,2.54,5.25,3.99,2.29,1.45,4.95,2.82,7.98,4.13,3.03,1.31,6.35,2.4,9.94,3.29,3.59.89,7.26,1.33,10.99,1.33,6.25,0,11.04-1.09,14.35-3.27,3.31-2.18,4.97-5.31,4.97-9.4,0-3.35-1.07-6.03-3.22-8.03-2.15-2-5.27-3.7-9.38-5.09-4.11-1.4-9.01-2.79-14.7-4.19-6.53-1.77-11.99-3.7-16.38-5.79-4.39-2.09-7.68-4.79-9.87-8.1-2.19-3.3-3.29-7.52-3.29-12.63,0-6.51,1.59-12.03,4.76-16.54,3.17-4.51,7.49-7.91,12.95-10.19s11.6-3.42,18.41-3.42c4.48,0,8.73.49,12.74,1.47,4.01.98,7.77,2.31,11.27,3.99,3.5,1.68,6.7,3.59,9.59,5.74l-7.14,12.88Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-2" d="M174.58,698.7c-.93-1.03-2.29-2.12-4.06-3.29-1.77-1.17-3.87-2.26-6.3-3.29-2.43-1.03-5.04-1.87-7.84-2.52-2.8-.65-5.69-.98-8.68-.98-6.53,0-11.39,1.21-14.56,3.63-3.17,2.42-4.76,5.77-4.76,10.05,0,3.16.89,5.65,2.66,7.47,1.77,1.82,4.48,3.33,8.12,4.54,3.64,1.21,8.21,2.51,13.72,3.91,6.72,1.58,12.55,3.47,17.5,5.65,4.95,2.19,8.73,5.09,11.34,8.72,2.61,3.63,3.92,8.42,3.92,14.37,0,5.03-.93,9.35-2.8,12.98-1.87,3.63-4.48,6.58-7.84,8.86s-7.23,3.96-11.62,5.02c-4.39,1.07-9.1,1.6-14.14,1.6s-9.87-.51-14.77-1.54c-4.9-1.03-9.57-2.54-14-4.55-4.43-2.01-8.52-4.46-12.25-7.35l7.14-13.44c1.21,1.21,2.96,2.54,5.25,3.99,2.29,1.45,4.95,2.82,7.98,4.13,3.03,1.31,6.35,2.4,9.94,3.29,3.59.89,7.26,1.33,10.99,1.33,6.25,0,11.04-1.09,14.35-3.27,3.31-2.18,4.97-5.31,4.97-9.4,0-3.35-1.07-6.03-3.22-8.03-2.15-2-5.27-3.7-9.38-5.09-4.11-1.4-9.01-2.79-14.7-4.19-6.53-1.77-11.99-3.7-16.38-5.79-4.39-2.09-7.68-4.79-9.87-8.1-2.19-3.3-3.29-7.52-3.29-12.63,0-6.51,1.59-12.03,4.76-16.54,3.17-4.51,7.49-7.91,12.95-10.19s11.6-3.42,18.41-3.42c4.48,0,8.73.49,12.74,1.47,4.01.98,7.77,2.31,11.27,3.99,3.5,1.68,6.7,3.59,9.59,5.74l-7.14,12.88Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-4" d="M285.4,698.7c-.93-1.03-2.29-2.12-4.06-3.29-1.77-1.17-3.87-2.26-6.3-3.29-2.43-1.03-5.04-1.87-7.84-2.52-2.8-.65-5.69-.98-8.68-.98-6.53,0-11.39,1.21-14.56,3.63-3.17,2.42-4.76,5.77-4.76,10.05,0,3.16.89,5.65,2.66,7.47,1.77,1.82,4.48,3.33,8.12,4.54,3.64,1.21,8.21,2.51,13.72,3.91,6.72,1.58,12.55,3.47,17.5,5.65,4.95,2.19,8.73,5.09,11.34,8.72,2.61,3.63,3.92,8.42,3.92,14.37,0,5.03-.93,9.35-2.8,12.98-1.87,3.63-4.48,6.58-7.84,8.86s-7.23,3.96-11.62,5.02c-4.39,1.07-9.1,1.6-14.14,1.6s-9.87-.51-14.77-1.54c-4.9-1.03-9.57-2.54-14-4.55-4.43-2.01-8.52-4.46-12.25-7.35l7.14-13.44c1.21,1.21,2.96,2.54,5.25,3.99,2.29,1.45,4.95,2.82,7.98,4.13,3.03,1.31,6.35,2.4,9.94,3.29,3.59.89,7.26,1.33,10.99,1.33,6.25,0,11.04-1.09,14.35-3.27,3.31-2.18,4.97-5.31,4.97-9.4,0-3.35-1.07-6.03-3.22-8.03-2.15-2-5.27-3.7-9.38-5.09-4.11-1.4-9.01-2.79-14.7-4.19-6.53-1.77-11.99-3.7-16.38-5.79-4.39-2.09-7.68-4.79-9.87-8.1-2.19-3.3-3.29-7.52-3.29-12.63,0-6.51,1.59-12.03,4.76-16.54,3.17-4.51,7.49-7.91,12.95-10.19s11.6-3.42,18.41-3.42c4.48,0,8.73.49,12.74,1.47,4.01.98,7.77,2.31,11.27,3.99,3.5,1.68,6.7,3.59,9.59,5.74l-7.14,12.88Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-2" d="M285.4,698.7c-.93-1.03-2.29-2.12-4.06-3.29-1.77-1.17-3.87-2.26-6.3-3.29-2.43-1.03-5.04-1.87-7.84-2.52-2.8-.65-5.69-.98-8.68-.98-6.53,0-11.39,1.21-14.56,3.63-3.17,2.42-4.76,5.77-4.76,10.05,0,3.16.89,5.65,2.66,7.47,1.77,1.82,4.48,3.33,8.12,4.54,3.64,1.21,8.21,2.51,13.72,3.91,6.72,1.58,12.55,3.47,17.5,5.65,4.95,2.19,8.73,5.09,11.34,8.72,2.61,3.63,3.92,8.42,3.92,14.37,0,5.03-.93,9.35-2.8,12.98-1.87,3.63-4.48,6.58-7.84,8.86s-7.23,3.96-11.62,5.02c-4.39,1.07-9.1,1.6-14.14,1.6s-9.87-.51-14.77-1.54c-4.9-1.03-9.57-2.54-14-4.55-4.43-2.01-8.52-4.46-12.25-7.35l7.14-13.44c1.21,1.21,2.96,2.54,5.25,3.99,2.29,1.45,4.95,2.82,7.98,4.13,3.03,1.31,6.35,2.4,9.94,3.29,3.59.89,7.26,1.33,10.99,1.33,6.25,0,11.04-1.09,14.35-3.27,3.31-2.18,4.97-5.31,4.97-9.4,0-3.35-1.07-6.03-3.22-8.03-2.15-2-5.27-3.7-9.38-5.09-4.11-1.4-9.01-2.79-14.7-4.19-6.53-1.77-11.99-3.7-16.38-5.79-4.39-2.09-7.68-4.79-9.87-8.1-2.19-3.3-3.29-7.52-3.29-12.63,0-6.51,1.59-12.03,4.76-16.54,3.17-4.51,7.49-7.91,12.95-10.19s11.6-3.42,18.41-3.42c4.48,0,8.73.49,12.74,1.47,4.01.98,7.77,2.31,11.27,3.99,3.5,1.68,6.7,3.59,9.59,5.74l-7.14,12.88Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-4" d="M405.92,760.86v13.86h-68.18v-99.4h66.92v13.86h-51.24v28.28h44.38v13.02h-44.38v30.38h52.5Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-2" d="M405.92,760.86v13.86h-68.18v-99.4h66.92v13.86h-51.24v28.28h44.38v13.02h-44.38v30.38h52.5Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-4" d="M462.08,704.44v70.28h-15.68v-99.4h12.88l56.28,71.82v-71.68h15.82v99.26h-13.72l-55.58-70.28Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-2" d="M462.08,704.44v70.28h-15.68v-99.4h12.88l56.28,71.82v-71.68h15.82v99.26h-13.72l-55.58-70.28Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-4" d="M572.84,724.18c0-6.07,1.07-12.02,3.22-17.85,2.15-5.83,5.3-11.15,9.45-15.96,4.15-4.81,9.22-8.63,15.19-11.48,5.97-2.85,12.74-4.27,20.3-4.27,8.96,0,16.71,2.03,23.24,6.09,6.53,4.06,11.39,9.26,14.56,15.61l-12.32,8.26c-1.87-4.01-4.22-7.19-7.07-9.52-2.85-2.33-5.93-3.97-9.24-4.9-3.31-.93-6.56-1.4-9.73-1.4-5.23,0-9.8,1.05-13.72,3.15-3.92,2.1-7.21,4.88-9.87,8.33-2.66,3.45-4.67,7.33-6.02,11.62-1.35,4.29-2.03,8.59-2.03,12.88,0,4.76.79,9.36,2.38,13.79,1.59,4.43,3.8,8.35,6.65,11.76,2.85,3.41,6.23,6.09,10.15,8.05s8.21,2.94,12.88,2.94c3.17,0,6.49-.56,9.94-1.68s6.65-2.87,9.59-5.25,5.25-5.53,6.93-9.45l13.02,7.42c-2.05,4.95-5.25,9.15-9.59,12.6-4.34,3.45-9.2,6.07-14.56,7.84-5.37,1.77-10.66,2.66-15.89,2.66-7,0-13.39-1.47-19.18-4.41-5.79-2.94-10.78-6.86-14.98-11.76-4.2-4.9-7.47-10.41-9.8-16.52-2.33-6.11-3.5-12.3-3.5-18.55Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-2" d="M572.84,724.18c0-6.07,1.07-12.02,3.22-17.85,2.15-5.83,5.3-11.15,9.45-15.96,4.15-4.81,9.22-8.63,15.19-11.48,5.97-2.85,12.74-4.27,20.3-4.27,8.96,0,16.71,2.03,23.24,6.09,6.53,4.06,11.39,9.26,14.56,15.61l-12.32,8.26c-1.87-4.01-4.22-7.19-7.07-9.52-2.85-2.33-5.93-3.97-9.24-4.9-3.31-.93-6.56-1.4-9.73-1.4-5.23,0-9.8,1.05-13.72,3.15-3.92,2.1-7.21,4.88-9.87,8.33-2.66,3.45-4.67,7.33-6.02,11.62-1.35,4.29-2.03,8.59-2.03,12.88,0,4.76.79,9.36,2.38,13.79,1.59,4.43,3.8,8.35,6.65,11.76,2.85,3.41,6.23,6.09,10.15,8.05s8.21,2.94,12.88,2.94c3.17,0,6.49-.56,9.94-1.68s6.65-2.87,9.59-5.25,5.25-5.53,6.93-9.45l13.02,7.42c-2.05,4.95-5.25,9.15-9.59,12.6-4.34,3.45-9.2,6.07-14.56,7.84-5.37,1.77-10.66,2.66-15.89,2.66-7,0-13.39-1.47-19.18-4.41-5.79-2.94-10.78-6.86-14.98-11.76-4.2-4.9-7.47-10.41-9.8-16.52-2.33-6.11-3.5-12.3-3.5-18.55Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-4" d="M767.79,760.86v13.86h-68.18v-99.4h66.92v13.86h-51.24v28.28h44.38v13.02h-44.38v30.38h52.5Z"></path>
</g>
<g class="essd-cls-3">
<path class="essd-cls-2" d="M767.79,760.86v13.86h-68.18v-99.4h66.92v13.86h-51.24v28.28h44.38v13.02h-44.38v30.38h52.5Z"></path>
</g>
</g>
</svg>
</div><div class="door-content"><div class="door-discipline">Products</div><h3 class="door-heading didot">AM ESSENCE</h3><div class="door-rule"></div><p class="door-tagline">Every product passes one filter — does it increase the standard or dilute it? No middle ground.</p><button class="door-cta" data-nav="essence">Explore</button></div></div>
<div class="door"><div class="door-logo">
<svg data-name="Layer 1" id="att-layer" style="height:130px;width:auto;display:block;margin:0 auto" viewbox="0 0 1785 1179.57" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
<lineargradient gradientunits="userSpaceOnUse" id="att-linear-gradient" x1="896.29" x2="888.99" y1="177.44" y2="747.11">
<stop offset="0" stop-color="#b3b3b3"></stop>
<stop offset="1" stop-color="gray"></stop>
</lineargradient>
</defs>
<polygon class="att-cls-1" points="892.5 270.58 966.19 473.38 1042.47 473.38 1016.12 400.9 930.78 166.03 893.26 166.03 891.74 166.03 854.22 166.03 768.88 400.9 742.53 473.38 818.81 473.38 892.5 270.58"></polygon>
<polygon class="att-cls-4" points="1050.6 495.75 1050.28 494.89 974.01 494.89 974.35 495.83 892.5 685.86 810.65 495.83 810.99 494.89 734.72 494.89 734.4 495.75 627.27 790.59 703.53 790.59 776.18 590.67 862.25 790.59 891.74 790.59 893.26 790.59 922.75 790.59 1008.82 590.67 1081.47 790.59 1157.73 790.59 1050.6 495.75"></polygon>
<text class="att-cls-5" transform="translate(518.59 1002.94)"><tspan class="att-cls-8" x="0" y="0">A</tspan><tspan class="att-cls-3" x="123.59" y="0">T</tspan><tspan class="att-cls-6" x="267.75" y="0">TI</tspan><tspan class="att-cls-7" x="498.09" y="0">R</tspan><tspan class="att-cls-6" x="640.38" y="0">E</tspan></text>
<rect class="att-cls-2" height="1150" width="1765" x="10" y="10"></rect>
</svg>
</div><div class="door-content"><div class="door-discipline">Identity</div><h3 class="door-heading">AM <em>Attire</em></h3><div class="door-rule"></div><p class="door-tagline">Not merch. Not fashion. Identity over image — for the man who knows exactly who he is.</p><button class="door-cta" data-nav="attire">Explore</button></div></div>
</div>
</section>
<div class="closing-cta"><p>Your Standard Starts Here.</p></div>
</div>
<!-- ═══ BARBER LOUNGE ═══ -->
<div class="page" id="page-barber-lounge">
<section class="page-hero">
<span class="bracket bracket-tl"></span><span class="bracket bracket-tr"></span>
<span class="bracket bracket-bl"></span><span class="bracket bracket-br"></span>
<div class="page-hero-content">
<svg data-name="Layer 1" id="blp-layer" style="height:160px;width:auto;display:block;margin:0 auto 2.5rem;filter:drop-shadow(0 0 30px rgba(184,146,42,.08))" viewbox="0 0 1395.21 808.23" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
<lineargradient gradienttransform="translate(0 998.96) scale(1 -1)" gradientunits="userSpaceOnUse" id="blp-linear-gradient" x1="701.4" x2="694.1" y1="987.56" y2="418.56">
<stop offset="0" stop-color="#b3b3b3"></stop>
<stop offset="1" stop-color="gray"></stop>
</lineargradient>
</defs>
<polygon class="blp-cls-4" points="697.6 104.43 771.22 307 847.4 307 821.09 234.59 735.85 0 698.37 0 696.84 0 659.37 0 574.13 234.59 547.82 307 624 307 697.6 104.43"></polygon>
<polygon class="blp-cls-3" points="855.86 328.86 855.55 328 779.19 328 779.53 328.94 697.61 519.16 615.68 328.94 616.02 328 539.67 328 539.36 328.86 432.11 624 508.46 624 581.17 423.87 667.32 624 696.84 624 698.37 624 727.89 624 814.05 423.87 886.76 624 963.1 624 855.86 328.86"></polygon>
<g class="blp-cls-2">
<text class="blp-cls-1" transform="translate(.13 770.73)"><tspan class="blp-cls-5" x="0" y="0">B</tspan><tspan x="106.54" xml:space="preserve" y="0">ARBER  </tspan><tspan class="blp-cls-5" x="736.54" y="0">L</tspan><tspan x="827.54" y="0">OUNGE</tspan></text>
<text></text>
</g>
</svg>
<span class="page-eyebrow">House of AM</span>
<h1>Premium Grooming Services</h1>
<span class="page-hero-sub">Defined by standards. Not routine.</span>
</div>
</section>
<section class="section-parch">
<div class="shell">
<div class="section-head"><span class="section-eyebrow">AM Barber Lounge</span><h2>The <em>Services</em></h2><hr class="gold-rule-center"/></div>
<div class="pricing-card-wrap">
<div class="pricing-cols">
<div class="pricing-col col-std">
<div class="pricing-col-head">Standard</div>
<span class="pc-cat">Full Grooming</span>
<div class="pc-row"><span>Skinfade / Taperfade &amp; Beard</span><span class="pc-price">£46</span></div>
<div class="pc-row"><span>Hair &amp; Beard</span><span class="pc-price">£43</span></div>
<span class="pc-cat">Cuts</span>
<div class="pc-row"><span>Skinfade / Taperfade</span><span class="pc-price">£29</span></div>
<div class="pc-row"><span>Haircut</span><span class="pc-price">£26</span></div>
</div>
<div class="pricing-col">
<div class="pricing-col-head gold">Members</div>
<span class="pc-cat">Full Grooming</span>
<div class="pc-row"><span>Skinfade / Taperfade &amp; Beard</span><span class="pc-price">£32</span></div>
<div class="pc-row"><span>Hair &amp; Beard</span><span class="pc-price">£30</span></div>
<span class="pc-cat">Cuts</span>
<div class="pc-row"><span>Skinfade / Taperfade</span><span class="pc-price">£20</span></div>
<div class="pc-row"><span>Haircut</span><span class="pc-price">£18</span></div>
</div>
</div>
</div>
</div>
</section>
<div class="disc-section">
<div class="disc-inner">
<div class="disc-eyebrow">Discounted Services</div>
<div class="disc-cards">
<div class="disc-card">
<span class="disc-card-label">Under 16</span>
<div class="disc-card-price">£19</div>
<div class="disc-card-note">No Skinfade</div>
</div>
<div class="disc-card">
<span class="disc-card-label">Under 12</span>
<div class="disc-card-price">£14</div>
<div class="disc-card-note">No Skinfade</div>
</div>
<div class="disc-card">
<span class="disc-card-label">Pensioners</span>
<div class="disc-card-price">£19</div>
<div class="disc-card-note">No Skinfade</div>
</div>
</div>
<div class="disc-avail">Available Monday To Wednesday Only</div>
</div>
</div>
<div class="addl-section">
<div class="addl-inner">
<div class="addl-eyebrow">Additional Services</div>
<div class="addl-tier-label">Standard</div>
<div class="addl-cards addl-four">
<div class="addl-card">
<div class="addl-card-head">Shaving</div>
<div class="addl-row"><span>Luxury Wet Shave</span><span class="addl-price">£29</span></div>
<div class="addl-row"><span>Wet Shave</span><span class="addl-price">£22</span></div>
<div class="addl-row"><span>Head Shave — Razor</span><span class="addl-price">£22</span></div>
<div class="addl-row"><span>Head Shave — Foils</span><span class="addl-price">£18</span></div>
</div>
<div class="addl-card">
<div class="addl-card-head">Beard</div>
<div class="addl-row"><span>Beard Trim &amp; Shape Up</span><span class="addl-price">£18</span></div>
<div class="addl-row"><span>Beard Tidy &amp; Line Up</span><span class="addl-price">£12</span></div>
<div class="addl-row"><span>Beard Line Up</span><span class="addl-price">£8</span></div>
</div>
<div class="addl-card">
<div class="addl-card-head">Skin</div>
<div class="addl-row"><span>Deluxe Facial</span><span class="addl-price">£48</span></div>
<div class="addl-row"><span>Facial</span><span class="addl-price">£30</span></div>
<div class="addl-row"><span>Express Facial</span><span class="addl-price">£12</span></div>
</div>
<div class="addl-card">
<div class="addl-card-head">Extras</div>
<div class="addl-row"><span>Gold Mask</span><span class="addl-price">£18</span></div>
<div class="addl-row"><span>Black Mask</span><span class="addl-price">£12</span></div>
<div class="addl-row"><span>Full Face Waxing</span><span class="addl-price">£12</span></div>
<div class="addl-row"><span>Ear &amp; Nose Waxing</span><span class="addl-price">£6</span></div>
</div>
</div>
<div class="addl-tier-label addl-tier-gold">Members</div>
<div class="addl-cards addl-four addl-members">
<div class="addl-card">
<div class="addl-card-head">Shaving</div>
<div class="addl-row"><span>Luxury Wet Shave</span><span class="addl-price">£24</span></div>
<div class="addl-row"><span>Wet Shave</span><span class="addl-price">£18</span></div>
<div class="addl-row"><span>Head Shave — Razor</span><span class="addl-price">£20</span></div>
<div class="addl-row"><span>Head Shave — Foils</span><span class="addl-price">£15</span></div>
</div>
<div class="addl-card">
<div class="addl-card-head">Beard</div>
<div class="addl-row"><span>Beard Trim &amp; Shape Up</span><span class="addl-price">£15</span></div>
<div class="addl-row"><span>Beard Tidy &amp; Line Up</span><span class="addl-price">£10</span></div>
<div class="addl-row"><span>Beard Line Up</span><span class="addl-price">£7</span></div>
</div>
<div class="addl-card">
<div class="addl-card-head">Skin</div>
<div class="addl-row"><span>Deluxe Facial</span><span class="addl-price">£40</span></div>
<div class="addl-row"><span>Facial</span><span class="addl-price">£25</span></div>
<div class="addl-row"><span>Express Facial</span><span class="addl-price">£10</span></div>
</div>
<div class="addl-card">
<div class="addl-card-head">Extras</div>
<div class="addl-row"><span>Gold Mask</span><span class="addl-price">£15</span></div>
<div class="addl-row"><span>Black Mask</span><span class="addl-price">£10</span></div>
<div class="addl-row"><span>Full Face Waxing</span><span class="addl-price">£10</span></div>
<div class="addl-row"><span>Ear &amp; Nose Waxing</span><span class="addl-price">£5</span></div>
</div>
</div>
</div>
</div>
<section class="section-parch"><div class="shell"><div class="members-block members-block-bold"><h3 class="mem-h3-large">AM MEMBERS</h3><p>This is not a discount. It is locked pricing.</p><p class="locked">Lock your rate for 12 months — Closed</p></div></div></section>
<div class="closing-cta"><p>Your Standard Starts Here.</p></div>
</div>
<!-- ═══ RENOVAIR ═══ -->
<div class="page" id="page-renovair">
<section class="page-hero">
<span class="bracket bracket-tl"></span><span class="bracket bracket-tr"></span>
<span class="bracket bracket-bl"></span><span class="bracket bracket-br"></span>
<div class="page-hero-content">
<img alt="AM Rénovaïr" class="page-hero-logo" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2aWV3Qm94PSIwIDAgNTg0LjMgNTM4LjciPgogIDxkZWZzPgogICAgPHN0eWxlPgogICAgICAuY2xzLTEgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTcpOwogICAgICB9CgogICAgICAuY2xzLTIgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTUpOwogICAgICB9CgogICAgICAuY2xzLTMgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTYpOwogICAgICB9CgogICAgICAuY2xzLTQgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTQpOwogICAgICB9CgogICAgICAuY2xzLTUgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTMpOwogICAgICB9CgogICAgICAuY2xzLTYgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50LTIpOwogICAgICB9CgogICAgICAuY2xzLTcgewogICAgICAgIGZpbGw6IHVybCgjbGluZWFyLWdyYWRpZW50KTsKICAgICAgfQoKICAgICAgLmNscy04IHsKICAgICAgICBmaWxsOiAjYjM5ODcwOwogICAgICB9CiAgICA8L3N0eWxlPgogICAgPGxpbmVhckdyYWRpZW50IGlkPSJsaW5lYXItZ3JhZGllbnQiIHgxPSIxOTQuNjYiIHkxPSI0MDcuMTUiIHgyPSIzODUuNDQiIHkyPSI0MDcuMTUiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA3MjcuODYpIHNjYWxlKDEgLTEpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2RkYzE4ZSIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiMTkxNWQiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICA8bGluZWFyR3JhZGllbnQgaWQ9ImxpbmVhci1ncmFkaWVudC0yIiB4MT0iMTQ3Ljk2IiB5MT0iNTY1Ljc5IiB4Mj0iMjY3LjIyIiB5Mj0iNTY1Ljc5IiBncmFkaWVudFRyYW5zZm9ybT0idHJhbnNsYXRlKDAgNzI3Ljg2KSBzY2FsZSgxIC0xKSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNkZGMxOGUiLz4KICAgICAgPHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjYjE5MTVkIi8+CiAgICA8L2xpbmVhckdyYWRpZW50PgogICAgPGxpbmVhckdyYWRpZW50IGlkPSJsaW5lYXItZ3JhZGllbnQtMyIgeDE9IjMxMy4wMyIgeTE9IjU2NS44IiB4Mj0iNDMyLjI5IiB5Mj0iNTY1LjgiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA3MjcuODYpIHNjYWxlKDEgLTEpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2RkYzE4ZSIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiMTkxNWQiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICA8bGluZWFyR3JhZGllbnQgaWQ9ImxpbmVhci1ncmFkaWVudC00IiB4MT0iMjMxLjA0IiB5MT0iNjM4LjM2IiB4Mj0iMzQ5LjIzIiB5Mj0iNjM4LjM2IiBncmFkaWVudFRyYW5zZm9ybT0idHJhbnNsYXRlKDAgNzI3Ljg2KSBzY2FsZSgxIC0xKSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgogICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNiM2IzYjMiLz4KICAgICAgPHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSJncmF5Ii8+CiAgICA8L2xpbmVhckdyYWRpZW50PgogICAgPGxpbmVhckdyYWRpZW50IGlkPSJsaW5lYXItZ3JhZGllbnQtNSIgeDE9IjE2MC43MiIgeTE9IjUwOS43OCIgeDI9IjQxOS41NSIgeTI9IjUwOS43OCIgZ3JhZGllbnRUcmFuc2Zvcm09InRyYW5zbGF0ZSgwIDcyNy44Nikgc2NhbGUoMSAtMSkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgICAgPHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjZGRjMThlIi8+CiAgICAgIDxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI2IxOTE1ZCIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICAgIDxsaW5lYXJHcmFkaWVudCBpZD0ibGluZWFyLWdyYWRpZW50LTYiIHgxPSIxODQuNTQiIHkxPSI0MzIuNDQiIHgyPSIzOTUuNzIiIHkyPSI0MzIuNDQiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA3MjcuODYpIHNjYWxlKDEgLTEpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2RkYzE4ZSIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiMTkxNWQiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICA8bGluZWFyR3JhZGllbnQgaWQ9ImxpbmVhci1ncmFkaWVudC03IiB4MT0iOTEuODIiIHkxPSI1MjkuNTQiIHgyPSI0ODguNDUiIHkyPSI1MjkuNTQiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA3MjcuODYpIHNjYWxlKDEgLTEpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2RkYzE4ZSIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiMTkxNWQiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgPC9kZWZzPgogIDxnPgogICAgPGc+CiAgICAgIDxwYXRoIGNsYXNzPSJjbHMtNyIgZD0iTTM3OC44NywzMDIuMDdjLTEuMDgtLjI2LTIuMTItLjUtMy4xNi0uNzQtMS44LDEuNS0zLjY1LDIuOTUtNS41Miw0LjM2LTcuMjUtMS40MS0xNC40Ny0yLjM4LTIxLjY0LTIuNjYtMTEuNzgtLjQ2LTIyLjYzLDMuNC0zMy4xMSw3LjE1LTUuOTIsMi4xMS0xMi4wNSw0LjI5LTE4LjEyLDUuNTctMTMuOTYsMi45Ni0yNi4yOC0xLjQ0LTM5LjM1LTYuMDgtMy4xNi0xLjEzLTYuNDQtMi4zLTkuNzgtMy4zNy0xMy4xMy00LjI1LTI2LjA2LTMuNjYtMzguNzctMS4xMi0xLjgzLTEuMzctMy42MS0yLjc5LTUuMzUtNC4yNS0uOTUuMjQtMS45NC41LTIuOTIuNzYtMi4yLjYxLTQuNDEsMS4yNi02LjQ5LDEuODcsMS41MSwxLjM3LDMuMDQsMi43MSw0LjYyLDQuMDMsMi42NiwyLjIxLDUuNDEsNC4zMyw4LjIzLDYuMzYsMjMuMywxNi42OSw1MS44NSwyNi41NCw4Mi42MywyNi41NHM1OC44MS05LjY2LDgyLTI2LjA4YzIuODgtMi4wNSw1LjctNC4yMSw4LjQzLTYuNDUsMS42NS0xLjM2LDMuMjgtMi43OCw0Ljg3LTQuMjEtMi4yNi0uNjEtNC40Ni0xLjE2LTYuNTYtMS42N2gtLjAxWk0yOTAuMTMsMzMyLjNjLTI2LjAzLDAtNTAuMzctNy40Ni03MC45OC0yMC4zOCw4Ljk5LTEuMDMsMTgtLjY3LDI2Ljg4LDIuMjEsMy4yNCwxLjA0LDYuNDYsMi4yLDkuNTgsMy4zLDE0LjAyLDUsMjcuMjUsOS43Myw0My4xNCw2LjM2LDYuNTMtMS4zOCwxMi44OC0zLjY1LDE5LjAyLTUuODUsMTAuMzEtMy42NywyMC4wNC03LjE1LDMwLjQ4LTYuNzMsNC4wMi4xNCw4LjA4LjU0LDEyLjE1LDEuMTItMjAuNDUsMTIuNjUtNDQuNTQsMTkuOTYtNzAuMjksMTkuOTZoLjAyWiIvPgogICAgICA8cGF0aCBjbGFzcz0iY2xzLTYiIGQ9Ik0yNjcuMjIsNTguMDJsLTQuNDksOS4xNWMtNjAuNzcsMTIuNjctMTA2LjU4LDY2LjY2LTEwNi41OCwxMzEuMTYsMCwyMS4wMSw0Ljg2LDQwLjkxLDEzLjUzLDU4LjY0bC0xLjUsMy4wMy0yLjk5LDYuMTFjLTEwLjk5LTIwLjE2LTE3LjIzLTQzLjI2LTE3LjIzLTY3Ljc4LDAtNzAuNTksNTEuNzItMTI5LjMzLDExOS4yNi0xNDAuMzFoMFoiLz4KICAgICAgPHBhdGggY2xhc3M9ImNscy01IiBkPSJNNDMyLjI5LDE5OC4zMmMwLDI0LjUxLTYuMjQsNDcuNjItMTcuMjMsNjcuNzhsLTIuOTktNi4xMS0xLjQ5LTMuMDRjOC42OC0xNy43MiwxMy41Mi0zNy42MSwxMy41Mi01OC42MywwLTY0LjUtNDUuOC0xMTguNDktMTA2LjU4LTEzMS4xNmwtMS40OS0zLjA1LTMtNi4xYzY3LjU0LDEwLjk4LDExOS4yNiw2OS43MSwxMTkuMjYsMTQwLjMxaDBaIi8+CiAgICAgIDxwb2x5Z29uIGNsYXNzPSJjbHMtNCIgcG9pbnRzPSIzNDkuMjMgMTQyLjEzIDMxNy44MyAxNDIuMTMgMjkwLjEzIDg1LjYyIDI2Mi40MyAxNDIuMTMgMjMxLjA0IDE0Mi4xMyAyMzEuNzEgMTQwLjc2IDIzMS43MSAxNDAuNzUgMjY4LjMxIDY2LjExIDI3Mi42NyA1Ny4yMyAyNzcuMTkgNDguMDIgMjgyLjY1IDM2Ljg2IDI5Ny42MSAzNi44NiAzMDMuMDcgNDguMDIgMzA3LjU5IDU3LjIzIDMxMS45NCA2Ni4xMSAzNDguNTQgMTQwLjc1IDM0OC41NCAxNDAuNzYgMzQ5LjIzIDE0Mi4xMyIvPgogICAgICA8cG9seWdvbiBjbGFzcz0iY2xzLTIiIHBvaW50cz0iNDE5LjU1IDI4NS41NyAzODguMTUgMjg1LjU3IDMzOS45MiAxODcuMTggMzM2Ljg4IDE4MSAzMDguNzcgMjM4LjMzIDMwNS43MyAyNDQuNTMgMjk4LjI4IDI1OS43NCAyODEuOTggMjU5Ljc0IDI3NC41MyAyNDQuNTMgMjcxLjUgMjM4LjMzIDI0My4zOCAxODEgMjQwLjM1IDE4Ny4xOCAxOTIuMTEgMjg1LjU3IDE2MC43MiAyODUuNTcgMTY3LjkyIDI3MC44OCAxNzIuMjggMjYxLjk5IDIyNC42NCAxNTUuMTcgMjI2Ljg5IDE1MC41OCAyNTkuODcgMTUwLjU4IDI4Ny4xOSAyMDYuMzEgMjkwLjEzIDIxMi4zMiAyOTMuMDYgMjA2LjMxIDMyMC4zOCAxNTAuNTggMzUzLjM2IDE1MC41OCAzNTUuNjEgMTU1LjE3IDQwNy45OSAyNjEuOTkgNDEyLjM1IDI3MC44OCA0MTkuNTUgMjg1LjU3Ii8+CiAgICAgIDxwYXRoIGNsYXNzPSJjbHMtMyIgZD0iTTM5NS43MiwyOTMuNDJjLTIuMDcsMi4yOS00LjIsNC41Mi02LjQxLDYuNjYtMy4xMi0uODYtNi4yNC0xLjY3LTkuMzYtMi40NC0xMC42Ni0yLjYxLTIxLjMyLTQuNTctMzEuNjgtNC45Ni0xMC40NC0uNDItMjAuMTcsMy4wNS0zMC40OSw2LjczLTYuMTIsMi4yLTEyLjQ4LDQuNDYtMTkuMDEsNS44NS0xNS44OCwzLjM3LTI5LjEyLTEuMzYtNDMuMTQtNi4zNS0zLjEyLTEuMTItNi4zNS0yLjI2LTkuNTgtMy4zMi0xNS4yNS00LjkyLTMwLjc4LTIuNDktNDYuMTEsMS43Mi0zLjA0LjgzLTYuMDgsMS43NC05LjExLDIuNjUtMi4xNi0yLjEyLTQuMjUtNC4zMS02LjI5LTYuNTYsMi45LS45LDUuNzktMS43OSw4LjctMi42NSwxNy44OC01LjI4LDM2LjIzLTkuMDYsNTQuOTUtMywzLjM0LDEuMDcsNi42MiwyLjI0LDkuNzgsMy4zNywxMy4wNiw0LjY2LDI1LjQsOS4wNCwzOS4zNSw2LjEsNi4wNy0xLjI5LDEyLjE5LTMuNDgsMTguMTItNS41OCwxMC40OC0zLjc0LDIxLjMzLTcuNjEsMzMuMTEtNy4xNSwxMi42NC41LDI1LjUsMy4xNSwzOC4yNiw2LjQ5LDIuOTguNzgsNS45NSwxLjU5LDguOTEsMi40NGgwWiIvPgogICAgPC9nPgogICAgPHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMjkwLjEzLDBDMTgwLjc4LDAsOTEuODIsODguOTcsOTEuODIsMTk4LjMyczg4Ljk2LDE5OC4zMSwxOTguMzEsMTk4LjMxLDE5OC4zMi04OC45NiwxOTguMzItMTk4LjMxUzM5OS40OCwwLDI5MC4xMywwWk0yOTAuMTMsNS45MWwuMDcuMTQtLjE4LjA4LjExLS4yMlpNMjkwLjEzLDM3Ny45MWMtOTkuMDQsMC0xNzkuNTktODAuNTYtMTc5LjU5LTE3OS41OSwwLTU0LjMsMjUuMjktMTA2LjUxLDY3LjctMTQwLjM5LDQ4LjgzLTM4Ljk5LDExNi43LTQ5Ljc4LDE3NS4xNi0yNy43MSw0OS43LDE4Ljc2LDg5LjQ2LDU5Ljc1LDEwNi42OSwxMTAsNi4zOSwxOC42OCw5LjY0LDM4LjM3LDkuNjQsNTguMTEsMCw5OS4wMi04MC41NiwxNzkuNTktMTc5LjYsMTc5LjU5aDBaIi8+CiAgPC9nPgogIDxnPgogICAgPHBhdGggY2xhc3M9ImNscy04IiBkPSJNNjAuMSw1MzYuOXYuNmMtMS42LjItNi42LjQtOS42LjQtNy4yLDAtOS0zLjItMjEuNC0zMC40LTEuNy0zLjYtMy40LTQuNC02LjYtNC40aC00LjF2MjEuNGMwLDcuNC40LDEyLjQsNy4yLDEyLjR2LjZIMHYtLjZjNi44LDAsNy4yLTUsNy4yLTEyLjR2LTQ2LjhjMC03LjQtLjQtMTIuNC03LjItMTIuNHYtLjZoMjdjMTYsMCwyNC44LDcuNCwyNC44LDE5LDAsOS44LTcuMywxNi0xNi4zLDE4LjR2LjJjMi45LDEuNyw1LjQsNS43LDcuOCwxMC4zLDEwLDE5LjIsMTIsMjIuNywxNi44LDI0LjNaTTE4LjQsNTAxLjVoNi44YzkuOSwwLDE1LTYuMSwxNS0xN3MtNC43LTE4LjItMTQuOS0xOC4yaC0zLjFjLTIuNCwwLTMuOCwxLjItMy44LDMuNnYzMS42WiIvPgogICAgPHBhdGggY2xhc3M9ImNscy04IiBkPSJNMTMzLjUsNTE5LjhsLTIuNCwxNy43aC01MS4zdi0uNmM2LjgsMCw3LjItNSw3LjItMTIuNHYtNDYuOGMwLTcuNC0uNC0xMi40LTcuMi0xMi40di0uNmg0OS44bDEuMywxNS44aC0uNmMtNS41LTExLjctOS4yLTE0LjItMjAuMi0xNC4yaC0xMS45djMyLjVoOS4xYzkuMywwLDExLjctMi41LDEzLjctOS45aC42djIyLjJoLS42Yy0yLTcuNC00LjQtMTAuNy0xMy43LTEwLjdoLTkuMXYzMC44YzAsMywuOSw0LjcsNCw0LjdoOS4zYzEwLjQsMCwxNS0yLjIsMjEuNC0xNi4xaC42Wk0xMDMuMiw0NTkuM2wtLjQtLjJjMi42LTYsNi4yLTE3LjUsNy41LTE5LjYuOS0xLjQsMi4yLTIuMiwzLjYtMi4yLDIuNiwwLDQuNCwyLjQsNC40LDQuMywwLC44LS4zLDEuNi0uOCwyLjQtMS4zLDIuMS0xMCwxMC4zLTE0LjMsMTUuM1oiLz4KICAgIDxwYXRoIGNsYXNzPSJjbHMtOCIgZD0iTTE5OS40LDQ2NC43aDE4Ljh2LjZjLTYuOCwwLTcuOCw3LjYtNy44LDE4LjR2NTVoLS42bC00My42LTY1LjN2NDUuM2MwLDEwLjQsMiwxOC4yLDkuMiwxOC4ydi42aC0xOS44di0uNmM2LjgsMCw4LjgtNy44LDguOC0xOC4ydi00Mi40YzAtNy4yLTMuNC0xMC4yLTguOC0xMXYtLjZoMThsMzUsNTIuOXYtMzMuOWMwLTEwLjgtMS42LTE4LjQtOS4yLTE4LjR2LS42WiIvPgogICAgPHBhdGggY2xhc3M9ImNscy04IiBkPSJNMjQwLjMsNTAxLjNjMC0yMi40LDEzLjItMzcuOCwzMy0zNy44czMyLjgsMTQuNiwzMi44LDM3LjQtMTMuMiwzNy44LTMzLDM3LjgtMzIuOC0xNC42LTMyLjgtMzcuNFpNMjkzLjcsNTAxLjFjMC0yMC4yLTctMzYuMi0yMC42LTM2LjJzLTIwLjQsMTUuNC0yMC40LDM2LjIsNywzNi4yLDIwLjYsMzYuMiwyMC40LTE1LjQsMjAuNC0zNi4yWiIvPgogICAgPHBhdGggY2xhc3M9ImNscy04IiBkPSJNMzcwLDQ2NC43aDE2Ljh2LjZjLTQuOC44LTcuMyw3LjMtMTEuNiwxOS4zbC0xOS41LDU0LjFoLS44bC0yMi02MS4yYy0yLjktOC4yLTQuOS0xMS44LTkuMS0xMi4ydi0uNmgyNS42di42Yy01LjYuNC03LjUsMy43LTUuNSw5LjVsMTYuMiw0Ni4zLDEzLjItMzcuMWM0LjItMTEuOCwzLjUtMTcuOS0zLjMtMTguN3YtLjZaIi8+CiAgICA8cGF0aCBjbGFzcz0iY2xzLTgiIGQ9Ik00NDUuNSw1MjQuN2MyLjksOC4yLDQuOSwxMS44LDkuMSwxMi4ydi42aC0yNS42di0uNmM1LjYtLjQsNy41LTQuMiw1LjYtOS41bC01LjItMTQuN2gtMjIuM2wtMiw1LjVjLTQuMiwxMS44LTMuNSwxNy45LDMuMywxOC43di42aC0xNi44di0uNmM0LjgtLjYsNy4zLTcuMywxMS42LTE5LjNsMTkuNS01NC4xaC44bDIyLDYxLjJaTTQwNy45LDUxMC4zaDIwLjdsLTEwLjMtMjkuMi0xMC40LDI5LjJaIi8+CiAgICA8cGF0aCBjbGFzcz0iY2xzLTgiIGQ9Ik00ODguMSw0MzguN2wxNS41LDIwLjEtLjMuNS0xNS41LTEwLjktMTUuNSwxMC45LS4zLS41LDE1LjUtMjAuMWguNlpNNDc1LDQ2NC43aDI1LjZ2LjZjLTYuOCwwLTcuMiw1LTcuMiwxMi40djQ2LjhjMCw3LjQuNCwxMi40LDcuMiwxMi40di42aC0yNS42di0uNmM2LjgsMCw3LjItNSw3LjItMTIuNHYtNDYuOGMwLTcuNC0uNC0xMi40LTcuMi0xMi40di0uNloiLz4KICAgIDxwYXRoIGNsYXNzPSJjbHMtOCIgZD0iTTU4NC4zLDUzNi45di42Yy0xLjYuMi02LjYuNC05LjYuNC03LjIsMC05LTMuMi0yMS40LTMwLjQtMS43LTMuNi0zLjQtNC40LTYuNi00LjRoLTQuMXYyMS40YzAsNy40LjQsMTIuNCw3LjIsMTIuNHYuNmgtMjUuNnYtLjZjNi44LDAsNy4yLTUsNy4yLTEyLjR2LTQ2LjhjMC03LjQtLjQtMTIuNC03LjItMTIuNHYtLjZoMjdjMTYsMCwyNC44LDcuNCwyNC44LDE5LDAsOS44LTcuMywxNi0xNi4zLDE4LjR2LjJjMi45LDEuNyw1LjQsNS43LDcuOCwxMC4zLDEwLDE5LjIsMTIsMjIuNywxNi44LDI0LjNaTTU0Mi42LDUwMS41aDYuOGM5LjksMCwxNS02LjEsMTUtMTdzLTQuNy0xOC4yLTE0LjktMTguMmgtMy4xYy0yLjQsMC0zLjgsMS4yLTMuOCwzLjZ2MzEuNloiLz4KICA8L2c+Cjwvc3ZnPg==" style="height:200px"/>
<span class="page-eyebrow">House of AM</span>
<h1>Recovery Studio</h1>
<span class="page-hero-sub">Rebuild. Recharge. Renovair.</span>
</div>
</section>
<section class="section-parch">
<div class="shell">
<div class="section-head"><span class="section-eyebrow">AM Renovair</span><h2>The <em>Services</em></h2><hr class="gold-rule-center"/></div>
<div class="pricing-card-wrap">
<div class="pricing-cols">
<div class="pricing-col col-std">
<div class="pricing-col-head">Standard</div>
<span class="pc-cat">Cupping</span>
<div class="pc-row"><span>Hijama (Wet)<span class="pc-note">Full Body</span></span><span class="pc-price">£80</span></div>
<div class="pc-row"><span>Hijama (Wet)<span class="pc-note">Half Body</span></span><span class="pc-price">£75</span></div>
<div class="pc-row"><span>Dry Cupping<span class="pc-note">Full Body</span></span><span class="pc-price">£70</span></div>
<div class="pc-row"><span>Dry Cupping<span class="pc-note">Half Body</span></span><span class="pc-price">£65</span></div>
<div class="pc-row"><span>Compression Therapy</span><span class="pc-price">£35</span></div>
<span class="pc-cat">Skin</span>
<div class="pc-row"><span>Deluxe Facial</span><span class="pc-price">£48</span></div>
<div class="pc-row"><span>Facial</span><span class="pc-price">£30</span></div>
<div class="pc-row"><span>Express Facial</span><span class="pc-price">£12</span></div>
</div>
<div class="pricing-col">
<div class="pricing-col-head gold">Members</div>
<span class="pc-cat">Cupping</span>
<div class="pc-row"><span>Hijama (Wet)<span class="pc-note">Full Body</span></span><span class="pc-price">£70</span></div>
<div class="pc-row"><span>Hijama (Wet)<span class="pc-note">Half Body</span></span><span class="pc-price">£65</span></div>
<div class="pc-row"><span>Dry Cupping<span class="pc-note">Full Body</span></span><span class="pc-price">£60</span></div>
<div class="pc-row"><span>Dry Cupping<span class="pc-note">Half Body</span></span><span class="pc-price">£55</span></div>
<div class="pc-row"><span>Compression Therapy</span><span class="pc-price">£25</span></div>
<span class="pc-cat">Skin</span>
<div class="pc-row"><span>Deluxe Facial</span><span class="pc-price">£40</span></div>
<div class="pc-row"><span>Facial</span><span class="pc-price">£25</span></div>
<div class="pc-row"><span>Express Facial</span><span class="pc-price">£10</span></div>
</div>
</div>
</div>
</div>
</section>
<!-- Rénovaïr Power Statement -->
<section class="section-ink" style="background:var(--ink);padding:clamp(3rem,6vw,5rem) var(--shell);text-align:center;position:relative;overflow:hidden">
<div style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 0%,rgba(198,156,109,.08),transparent 70%);pointer-events:none"></div>
<div style="max-width:720px;margin:0 auto;position:relative">
<span style="font-family:var(--ff-body);font-size:9px;letter-spacing:.38em;text-transform:uppercase;color:var(--gold);font-weight:600;display:block;margin-bottom:1.5rem">AM Rénovaïr · Harrow</span>
<h2 style="font-family:var(--ff-display);font-size:clamp(1.8rem,4.5vw,3.2rem);font-weight:500;color:var(--parchment);line-height:1.15;margin-bottom:1.5rem">Recovery Is Not A Luxury.<br/><em style="font-style:italic;color:var(--gold)">It Is The Standard.</em></h2>
<div style="width:40px;height:1px;background:linear-gradient(90deg,transparent,var(--gold),transparent);margin:0 auto 1.5rem"></div>
<p style="font-family:var(--ff-display);font-size:clamp(1rem,1.8vw,1.25rem);color:rgba(240,235,228,.65);line-height:1.7;font-style:italic">Hijama. Dry Cupping. Compression Therapy. Built for the man who operates at full capacity — and refuses to slow down.</p>
</div>
</section>
<!-- Treatment Frequency & Validity -->
<section class="section-cream">
<div class="shell">
<div class="section-head"><span class="section-eyebrow">Treatment Frequency &amp; Validity</span></div>
<div class="addl-cards">
<div class="addl-card">
<div class="addl-card-title">Hijama (Wet Cupping)</div>
<div class="pc-row"><span>Safe Frequency</span><span class="pc-price">Every 3 months</span></div>
<div class="pc-row"><span>Package Validity</span><span class="pc-price">4-Pack = 12 months</span></div>
<div class="pc-row"><span>Annual Max</span><span class="pc-price">4 sessions / year</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Dry Cupping</div>
<div class="pc-row"><span>Safe Frequency</span><span class="pc-price">Every 2 weeks</span></div>
<div class="pc-row"><span>Package Validity</span><span class="pc-price">3-Pack = 8 wks · 10-Pack = 6 mo</span></div>
<div class="pc-row"><span>Annual Max</span><span class="pc-price">26 sessions / year</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Compression Therapy</div>
<div class="pc-row"><span>Safe Frequency</span><span class="pc-price">1–2× per week</span></div>
<div class="pc-row"><span>Package Validity</span><span class="pc-price">3-Pack = 6 wks · 10-Pack = 3 mo</span></div>
<div class="pc-row"><span>Annual Max</span><span class="pc-price">Flexible / Ongoing</span></div>
</div>
</div>
</div>
</section>
<!-- Treatment Packages — Standard -->
<section class="section-parch">
<div class="shell">
<div class="section-head"><span class="section-eyebrow">Treatment Packages</span></div>
<div class="pricing-card-wrap">
<div class="pricing-col-label">Standard</div>
<div class="addl-cards">
<div class="addl-card">
<div class="addl-card-title">Dry Cupping – Full Body</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£201</span></div>
<div class="pc-row"><span>10-Pack</span><span class="pc-price">£650</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">8 wks / 6 mo</span></div>
<div class="pc-row"><span>Saving</span><span class="pc-price gold-txt">£9 / £50</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Dry Cupping – Half Body</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£156</span></div>
<div class="pc-row"><span>10-Pack</span><span class="pc-price">£500</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">8 wks / 6 mo</span></div>
<div class="pc-row"><span>Saving</span><span class="pc-price gold-txt">£9 / £50</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Hijama (Wet) – Full Body</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£231</span></div>
<div class="pc-row"><span>4-Pack</span><span class="pc-price">£300</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">12 months</span></div>
<div class="pc-row"><span>Saving</span><span class="pc-price gold-txt">£9 / £20</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Hijama (Wet) – Half Body</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£186</span></div>
<div class="pc-row"><span>4-Pack</span><span class="pc-price">£240</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">12 months</span></div>
<div class="pc-row"><span>Saving</span><span class="pc-price gold-txt">£9 / £20</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Compression Therapy</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£90</span></div>
<div class="pc-row"><span>10-Pack</span><span class="pc-price">£280</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">6 wks / 3 mo</span></div>
<div class="pc-row"><span>Saving</span><span class="pc-price gold-txt">£15 / £70</span></div>
</div>
<div class="addl-card" style="background:#faf6ef;border-color:rgba(184,146,42,.25)">
<div class="addl-card-title" style="color:var(--ink,#1a1714)">Hijama (Wet Cupping)</div>
<div style="font-family:var(--ff-body);font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:var(--gold,#b8922a);font-weight:600;margin-bottom:.75rem">Benefits</div>
<div style="font-family:var(--ff-display);font-size:.95rem;color:var(--ink,#1a1714);line-height:1.85">
<div style="margin-bottom:.35rem">— Removes toxins and stagnant blood</div>
<div style="margin-bottom:.35rem">— Boosts circulation and immunity</div>
<div style="margin-bottom:.35rem">— Relieves muscle tension and inflammation</div>
<div style="margin-bottom:.35rem">— Reduces stress, fatigue, and headaches</div>
<div>— Promotes overall body detox and balance</div>
</div>
</div>
<div class="addl-card" style="background:#faf6ef;border-color:rgba(184,146,42,.25)">
<div class="addl-card-title" style="color:var(--ink,#1a1714)">Dry Cupping</div>
<div style="font-family:var(--ff-body);font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:var(--gold,#b8922a);font-weight:600;margin-bottom:.75rem">Benefits</div>
<div style="font-family:var(--ff-display);font-size:.95rem;color:var(--ink,#1a1714);line-height:1.85">
<div style="margin-bottom:.35rem">— Increases blood flow and oxygen delivery</div>
<div style="margin-bottom:.35rem">— Reduces muscle stiffness and soreness</div>
<div style="margin-bottom:.35rem">— Aids recovery and improves mobility</div>
<div style="margin-bottom:.35rem">— Relieves tension, stress, and fatigue</div>
<div>— Stimulates lymphatic drainage and relaxation</div>
</div>
</div>
<div class="addl-card" style="background:#faf6ef;border-color:rgba(184,146,42,.25);grid-column:2/-1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:3rem 2rem;min-height:200px">
<div style="width:40px;height:1px;background:linear-gradient(90deg,transparent,#b8922a,transparent);margin:0 auto 1.5rem"></div>
<div style="font-family:var(--ff-display);font-size:clamp(1.4rem,2.5vw,2rem);font-weight:500;color:#1a1714;line-height:1.25;margin-bottom:1.25rem">The Body That Performs Best<br/><em style="font-style:italic;color:#b8922a">Is The One That Recovers Best.</em></div>
<div style="width:40px;height:1px;background:linear-gradient(90deg,transparent,#b8922a,transparent);margin:0 auto"></div>
</div>
</div>
</div>
</div>
</section>
<!-- Membership Packages — Members -->
<section class="section-cream">
<div class="shell">
<div class="section-head"><span class="section-eyebrow">Membership Packages</span></div>
<div class="pricing-card-wrap">
<div class="pricing-col-label gold">Members</div>
<div class="addl-cards">
<div class="addl-card">
<div class="addl-card-title">Dry Cupping – Full Body</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£171</span></div>
<div class="pc-row"><span>10-Pack</span><span class="pc-price">£550</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">8 wks / 6 mo</span></div>
<div class="pc-row"><span>Member Saving</span><span class="pc-price gold-txt">£9 / £50</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Dry Cupping – Half Body</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£141</span></div>
<div class="pc-row"><span>10-Pack</span><span class="pc-price">£450</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">8 wks / 6 mo</span></div>
<div class="pc-row"><span>Member Saving</span><span class="pc-price gold-txt">£9 / £50</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Hijama (Wet) – Full Body</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£201</span></div>
<div class="pc-row"><span>4-Pack</span><span class="pc-price">£260</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">12 months</span></div>
<div class="pc-row"><span>Member Saving</span><span class="pc-price gold-txt">£9 / £20</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Hijama (Wet) – Half Body</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£171</span></div>
<div class="pc-row"><span>4-Pack</span><span class="pc-price">£220</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">12 months</span></div>
<div class="pc-row"><span>Member Saving</span><span class="pc-price gold-txt">£9 / £20</span></div>
</div>
<div class="addl-card">
<div class="addl-card-title">Compression Therapy</div>
<div class="pc-row"><span>3-Pack</span><span class="pc-price">£66</span></div>
<div class="pc-row"><span>10-Pack</span><span class="pc-price">£200</span></div>
<div class="pc-row"><span>Validity</span><span class="pc-price">6 wks / 3 mo</span></div>
<div class="pc-row"><span>Member Saving</span><span class="pc-price gold-txt">£9 / £50</span></div>
</div>
<div class="addl-card" style="background:#faf6ef;border-color:rgba(184,146,42,.25)">
<div class="addl-card-title" style="color:var(--ink,#1a1714)">Hijama (Wet Cupping)</div>
<div style="font-family:var(--ff-body);font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:var(--gold,#b8922a);font-weight:600;margin-bottom:.75rem">Benefits</div>
<div style="font-family:var(--ff-display);font-size:.95rem;color:var(--ink,#1a1714);line-height:1.85">
<div style="margin-bottom:.35rem">— Removes toxins and stagnant blood</div>
<div style="margin-bottom:.35rem">— Boosts circulation and immunity</div>
<div style="margin-bottom:.35rem">— Relieves muscle tension and inflammation</div>
<div style="margin-bottom:.35rem">— Reduces stress, fatigue, and headaches</div>
<div>— Promotes overall body detox and balance</div>
</div>
</div>
<div class="addl-card" style="background:#faf6ef;border-color:rgba(184,146,42,.25)">
<div class="addl-card-title" style="color:var(--ink,#1a1714)">Dry Cupping</div>
<div style="font-family:var(--ff-body);font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:var(--gold,#b8922a);font-weight:600;margin-bottom:.75rem">Benefits</div>
<div style="font-family:var(--ff-display);font-size:.95rem;color:var(--ink,#1a1714);line-height:1.85">
<div style="margin-bottom:.35rem">— Increases blood flow and oxygen delivery</div>
<div style="margin-bottom:.35rem">— Reduces muscle stiffness and soreness</div>
<div style="margin-bottom:.35rem">— Aids recovery and improves mobility</div>
<div style="margin-bottom:.35rem">— Relieves tension, stress, and fatigue</div>
<div>— Stimulates lymphatic drainage and relaxation</div>
</div>
</div>
<div class="addl-card" style="background:#faf6ef;border-color:rgba(184,146,42,.25);grid-column:2/-1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:3rem 2rem;min-height:200px">
<div style="width:40px;height:1px;background:linear-gradient(90deg,transparent,#b8922a,transparent);margin:0 auto 1.5rem"></div>
<div style="font-family:var(--ff-display);font-size:clamp(1.4rem,2.5vw,2rem);font-weight:500;color:#1a1714;line-height:1.25;margin-bottom:1.25rem">Your Standard.<br/><em style="font-style:italic;color:#b8922a">Locked In. Paid Less. Every Time.</em></div>
<div style="width:40px;height:1px;background:linear-gradient(90deg,transparent,#b8922a,transparent);margin:0 auto"></div>
</div>
</div>
</div>
</div>
</section>
<section class="section-parch"><div class="shell"><div class="members-block members-block-bold"><h3 class="mem-h3-large">AM MEMBERS</h3><p>This is not a discount. It is locked pricing.</p><p class="locked">Lock your rate for 12 months — Closed</p></div></div></section>
<div class="closing-cta"><p>Your Standard Starts Here.</p></div>
</div>
<!-- ═══ ESSENCE ═══ -->
<div class="page" id="page-essence">
<section class="page-hero">
<span class="bracket bracket-tl"></span><span class="bracket bracket-tr"></span>
<span class="bracket bracket-bl"></span><span class="bracket bracket-br"></span>
<div class="page-hero-content">
<svg data-name="Layer 1" id="essp-layer" style="height:160px;width:auto;display:block;margin:0 auto 2.5rem;filter:drop-shadow(0 0 30px rgba(184,146,42,.08))" viewbox="0 0 772.79 780.42" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
<lineargradient gradienttransform="translate(0 899) scale(1 -1)" gradientunits="userSpaceOnUse" id="essp-linear-gradient" x1="390.19" x2="382.89" y1="887.59" y2="317.92">
<stop offset="0" stop-color="#b3b3b3"></stop>
<stop offset="1" stop-color="gray"></stop>
</lineargradient>
</defs>
<polygon class="essp-cls-1" points="386.39 104.55 460.09 307.36 536.36 307.36 510.02 234.87 424.68 0 387.16 0 385.63 0 348.11 0 262.77 234.87 236.43 307.36 312.7 307.36 386.39 104.55"></polygon>
<polygon class="essp-cls-4" points="544.49 329.72 544.18 328.86 467.9 328.86 468.24 329.8 386.4 519.83 304.55 329.8 304.89 328.86 228.61 328.86 228.3 329.72 121.16 624.57 197.43 624.57 270.07 424.64 356.14 624.57 385.63 624.57 387.16 624.57 416.65 624.57 502.72 424.64 575.36 624.57 651.63 624.57 544.49 329.72"></polygon>
<g class="essp-cls-3">
<g class="essp-cls-3">
<path class="essp-cls-4" d="M73.18,760.86v13.86H5v-99.4h66.92v13.86H20.68v28.28h44.38v13.02H20.68v30.38h52.5Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-2" d="M73.18,760.86v13.86H5v-99.4h66.92v13.86H20.68v28.28h44.38v13.02H20.68v30.38h52.5Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-4" d="M174.58,698.7c-.93-1.03-2.29-2.12-4.06-3.29-1.77-1.17-3.87-2.26-6.3-3.29-2.43-1.03-5.04-1.87-7.84-2.52-2.8-.65-5.69-.98-8.68-.98-6.53,0-11.39,1.21-14.56,3.63-3.17,2.42-4.76,5.77-4.76,10.05,0,3.16.89,5.65,2.66,7.47,1.77,1.82,4.48,3.33,8.12,4.54,3.64,1.21,8.21,2.51,13.72,3.91,6.72,1.58,12.55,3.47,17.5,5.65,4.95,2.19,8.73,5.09,11.34,8.72,2.61,3.63,3.92,8.42,3.92,14.37,0,5.03-.93,9.35-2.8,12.98-1.87,3.63-4.48,6.58-7.84,8.86s-7.23,3.96-11.62,5.02c-4.39,1.07-9.1,1.6-14.14,1.6s-9.87-.51-14.77-1.54c-4.9-1.03-9.57-2.54-14-4.55-4.43-2.01-8.52-4.46-12.25-7.35l7.14-13.44c1.21,1.21,2.96,2.54,5.25,3.99,2.29,1.45,4.95,2.82,7.98,4.13,3.03,1.31,6.35,2.4,9.94,3.29,3.59.89,7.26,1.33,10.99,1.33,6.25,0,11.04-1.09,14.35-3.27,3.31-2.18,4.97-5.31,4.97-9.4,0-3.35-1.07-6.03-3.22-8.03-2.15-2-5.27-3.7-9.38-5.09-4.11-1.4-9.01-2.79-14.7-4.19-6.53-1.77-11.99-3.7-16.38-5.79-4.39-2.09-7.68-4.79-9.87-8.1-2.19-3.3-3.29-7.52-3.29-12.63,0-6.51,1.59-12.03,4.76-16.54,3.17-4.51,7.49-7.91,12.95-10.19s11.6-3.42,18.41-3.42c4.48,0,8.73.49,12.74,1.47,4.01.98,7.77,2.31,11.27,3.99,3.5,1.68,6.7,3.59,9.59,5.74l-7.14,12.88Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-2" d="M174.58,698.7c-.93-1.03-2.29-2.12-4.06-3.29-1.77-1.17-3.87-2.26-6.3-3.29-2.43-1.03-5.04-1.87-7.84-2.52-2.8-.65-5.69-.98-8.68-.98-6.53,0-11.39,1.21-14.56,3.63-3.17,2.42-4.76,5.77-4.76,10.05,0,3.16.89,5.65,2.66,7.47,1.77,1.82,4.48,3.33,8.12,4.54,3.64,1.21,8.21,2.51,13.72,3.91,6.72,1.58,12.55,3.47,17.5,5.65,4.95,2.19,8.73,5.09,11.34,8.72,2.61,3.63,3.92,8.42,3.92,14.37,0,5.03-.93,9.35-2.8,12.98-1.87,3.63-4.48,6.58-7.84,8.86s-7.23,3.96-11.62,5.02c-4.39,1.07-9.1,1.6-14.14,1.6s-9.87-.51-14.77-1.54c-4.9-1.03-9.57-2.54-14-4.55-4.43-2.01-8.52-4.46-12.25-7.35l7.14-13.44c1.21,1.21,2.96,2.54,5.25,3.99,2.29,1.45,4.95,2.82,7.98,4.13,3.03,1.31,6.35,2.4,9.94,3.29,3.59.89,7.26,1.33,10.99,1.33,6.25,0,11.04-1.09,14.35-3.27,3.31-2.18,4.97-5.31,4.97-9.4,0-3.35-1.07-6.03-3.22-8.03-2.15-2-5.27-3.7-9.38-5.09-4.11-1.4-9.01-2.79-14.7-4.19-6.53-1.77-11.99-3.7-16.38-5.79-4.39-2.09-7.68-4.79-9.87-8.1-2.19-3.3-3.29-7.52-3.29-12.63,0-6.51,1.59-12.03,4.76-16.54,3.17-4.51,7.49-7.91,12.95-10.19s11.6-3.42,18.41-3.42c4.48,0,8.73.49,12.74,1.47,4.01.98,7.77,2.31,11.27,3.99,3.5,1.68,6.7,3.59,9.59,5.74l-7.14,12.88Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-4" d="M285.4,698.7c-.93-1.03-2.29-2.12-4.06-3.29-1.77-1.17-3.87-2.26-6.3-3.29-2.43-1.03-5.04-1.87-7.84-2.52-2.8-.65-5.69-.98-8.68-.98-6.53,0-11.39,1.21-14.56,3.63-3.17,2.42-4.76,5.77-4.76,10.05,0,3.16.89,5.65,2.66,7.47,1.77,1.82,4.48,3.33,8.12,4.54,3.64,1.21,8.21,2.51,13.72,3.91,6.72,1.58,12.55,3.47,17.5,5.65,4.95,2.19,8.73,5.09,11.34,8.72,2.61,3.63,3.92,8.42,3.92,14.37,0,5.03-.93,9.35-2.8,12.98-1.87,3.63-4.48,6.58-7.84,8.86s-7.23,3.96-11.62,5.02c-4.39,1.07-9.1,1.6-14.14,1.6s-9.87-.51-14.77-1.54c-4.9-1.03-9.57-2.54-14-4.55-4.43-2.01-8.52-4.46-12.25-7.35l7.14-13.44c1.21,1.21,2.96,2.54,5.25,3.99,2.29,1.45,4.95,2.82,7.98,4.13,3.03,1.31,6.35,2.4,9.94,3.29,3.59.89,7.26,1.33,10.99,1.33,6.25,0,11.04-1.09,14.35-3.27,3.31-2.18,4.97-5.31,4.97-9.4,0-3.35-1.07-6.03-3.22-8.03-2.15-2-5.27-3.7-9.38-5.09-4.11-1.4-9.01-2.79-14.7-4.19-6.53-1.77-11.99-3.7-16.38-5.79-4.39-2.09-7.68-4.79-9.87-8.1-2.19-3.3-3.29-7.52-3.29-12.63,0-6.51,1.59-12.03,4.76-16.54,3.17-4.51,7.49-7.91,12.95-10.19s11.6-3.42,18.41-3.42c4.48,0,8.73.49,12.74,1.47,4.01.98,7.77,2.31,11.27,3.99,3.5,1.68,6.7,3.59,9.59,5.74l-7.14,12.88Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-2" d="M285.4,698.7c-.93-1.03-2.29-2.12-4.06-3.29-1.77-1.17-3.87-2.26-6.3-3.29-2.43-1.03-5.04-1.87-7.84-2.52-2.8-.65-5.69-.98-8.68-.98-6.53,0-11.39,1.21-14.56,3.63-3.17,2.42-4.76,5.77-4.76,10.05,0,3.16.89,5.65,2.66,7.47,1.77,1.82,4.48,3.33,8.12,4.54,3.64,1.21,8.21,2.51,13.72,3.91,6.72,1.58,12.55,3.47,17.5,5.65,4.95,2.19,8.73,5.09,11.34,8.72,2.61,3.63,3.92,8.42,3.92,14.37,0,5.03-.93,9.35-2.8,12.98-1.87,3.63-4.48,6.58-7.84,8.86s-7.23,3.96-11.62,5.02c-4.39,1.07-9.1,1.6-14.14,1.6s-9.87-.51-14.77-1.54c-4.9-1.03-9.57-2.54-14-4.55-4.43-2.01-8.52-4.46-12.25-7.35l7.14-13.44c1.21,1.21,2.96,2.54,5.25,3.99,2.29,1.45,4.95,2.82,7.98,4.13,3.03,1.31,6.35,2.4,9.94,3.29,3.59.89,7.26,1.33,10.99,1.33,6.25,0,11.04-1.09,14.35-3.27,3.31-2.18,4.97-5.31,4.97-9.4,0-3.35-1.07-6.03-3.22-8.03-2.15-2-5.27-3.7-9.38-5.09-4.11-1.4-9.01-2.79-14.7-4.19-6.53-1.77-11.99-3.7-16.38-5.79-4.39-2.09-7.68-4.79-9.87-8.1-2.19-3.3-3.29-7.52-3.29-12.63,0-6.51,1.59-12.03,4.76-16.54,3.17-4.51,7.49-7.91,12.95-10.19s11.6-3.42,18.41-3.42c4.48,0,8.73.49,12.74,1.47,4.01.98,7.77,2.31,11.27,3.99,3.5,1.68,6.7,3.59,9.59,5.74l-7.14,12.88Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-4" d="M405.92,760.86v13.86h-68.18v-99.4h66.92v13.86h-51.24v28.28h44.38v13.02h-44.38v30.38h52.5Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-2" d="M405.92,760.86v13.86h-68.18v-99.4h66.92v13.86h-51.24v28.28h44.38v13.02h-44.38v30.38h52.5Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-4" d="M462.08,704.44v70.28h-15.68v-99.4h12.88l56.28,71.82v-71.68h15.82v99.26h-13.72l-55.58-70.28Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-2" d="M462.08,704.44v70.28h-15.68v-99.4h12.88l56.28,71.82v-71.68h15.82v99.26h-13.72l-55.58-70.28Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-4" d="M572.84,724.18c0-6.07,1.07-12.02,3.22-17.85,2.15-5.83,5.3-11.15,9.45-15.96,4.15-4.81,9.22-8.63,15.19-11.48,5.97-2.85,12.74-4.27,20.3-4.27,8.96,0,16.71,2.03,23.24,6.09,6.53,4.06,11.39,9.26,14.56,15.61l-12.32,8.26c-1.87-4.01-4.22-7.19-7.07-9.52-2.85-2.33-5.93-3.97-9.24-4.9-3.31-.93-6.56-1.4-9.73-1.4-5.23,0-9.8,1.05-13.72,3.15-3.92,2.1-7.21,4.88-9.87,8.33-2.66,3.45-4.67,7.33-6.02,11.62-1.35,4.29-2.03,8.59-2.03,12.88,0,4.76.79,9.36,2.38,13.79,1.59,4.43,3.8,8.35,6.65,11.76,2.85,3.41,6.23,6.09,10.15,8.05s8.21,2.94,12.88,2.94c3.17,0,6.49-.56,9.94-1.68s6.65-2.87,9.59-5.25,5.25-5.53,6.93-9.45l13.02,7.42c-2.05,4.95-5.25,9.15-9.59,12.6-4.34,3.45-9.2,6.07-14.56,7.84-5.37,1.77-10.66,2.66-15.89,2.66-7,0-13.39-1.47-19.18-4.41-5.79-2.94-10.78-6.86-14.98-11.76-4.2-4.9-7.47-10.41-9.8-16.52-2.33-6.11-3.5-12.3-3.5-18.55Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-2" d="M572.84,724.18c0-6.07,1.07-12.02,3.22-17.85,2.15-5.83,5.3-11.15,9.45-15.96,4.15-4.81,9.22-8.63,15.19-11.48,5.97-2.85,12.74-4.27,20.3-4.27,8.96,0,16.71,2.03,23.24,6.09,6.53,4.06,11.39,9.26,14.56,15.61l-12.32,8.26c-1.87-4.01-4.22-7.19-7.07-9.52-2.85-2.33-5.93-3.97-9.24-4.9-3.31-.93-6.56-1.4-9.73-1.4-5.23,0-9.8,1.05-13.72,3.15-3.92,2.1-7.21,4.88-9.87,8.33-2.66,3.45-4.67,7.33-6.02,11.62-1.35,4.29-2.03,8.59-2.03,12.88,0,4.76.79,9.36,2.38,13.79,1.59,4.43,3.8,8.35,6.65,11.76,2.85,3.41,6.23,6.09,10.15,8.05s8.21,2.94,12.88,2.94c3.17,0,6.49-.56,9.94-1.68s6.65-2.87,9.59-5.25,5.25-5.53,6.93-9.45l13.02,7.42c-2.05,4.95-5.25,9.15-9.59,12.6-4.34,3.45-9.2,6.07-14.56,7.84-5.37,1.77-10.66,2.66-15.89,2.66-7,0-13.39-1.47-19.18-4.41-5.79-2.94-10.78-6.86-14.98-11.76-4.2-4.9-7.47-10.41-9.8-16.52-2.33-6.11-3.5-12.3-3.5-18.55Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-4" d="M767.79,760.86v13.86h-68.18v-99.4h66.92v13.86h-51.24v28.28h44.38v13.02h-44.38v30.38h52.5Z"></path>
</g>
<g class="essp-cls-3">
<path class="essp-cls-2" d="M767.79,760.86v13.86h-68.18v-99.4h66.92v13.86h-51.24v28.28h44.38v13.02h-44.38v30.38h52.5Z"></path>
</g>
</g>
</svg>
<span class="page-eyebrow">House of AM</span>
<h1>Premium Products</h1>
<span class="page-hero-sub">Refined. Restored. Defined.</span>
</div>
</section>
<div class="closing-cta"><p>Please Visit Our Store</p><p style="margin-top:.5rem"><a href="https://www.google.com/maps/dir/?api=1&amp;destination=329+High+Road+Harrow+HA3+5EQ" rel="noopener" style="color:var(--gold);font-family:var(--ff-body);font-size:9px;letter-spacing:.25em;text-transform:uppercase;font-weight:600;border-bottom:1px solid var(--gold);padding-bottom:2px" target="_blank">329 High Road, Harrow, HA3 5EQ</a></p></div>
</div>
<!-- ═══ ATTIRE ═══ -->
<div class="page" id="page-attire">
<section class="page-hero">
<span class="bracket bracket-tl"></span><span class="bracket bracket-tr"></span>
<span class="bracket bracket-bl"></span><span class="bracket bracket-br"></span>
<div class="page-hero-content">
<svg class="page-hero-logo" data-name="Layer 1" id="att-page-layer" viewbox="0 0 1785 1179.57" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
<lineargradient gradientunits="userSpaceOnUse" id="attp-linear-gradient" x1="896.29" x2="888.99" y1="177.44" y2="747.11">
<stop offset="0" stop-color="#b3b3b3"></stop>
<stop offset="1" stop-color="gray"></stop>
</lineargradient>
</defs>
<polygon class="attp-cls-1" points="892.5 270.58 966.19 473.38 1042.47 473.38 1016.12 400.9 930.78 166.03 893.26 166.03 891.74 166.03 854.22 166.03 768.88 400.9 742.53 473.38 818.81 473.38 892.5 270.58"></polygon>
<polygon class="attp-cls-4" points="1050.6 495.75 1050.28 494.89 974.01 494.89 974.35 495.83 892.5 685.86 810.65 495.83 810.99 494.89 734.72 494.89 734.4 495.75 627.27 790.59 703.53 790.59 776.18 590.67 862.25 790.59 891.74 790.59 893.26 790.59 922.75 790.59 1008.82 590.67 1081.47 790.59 1157.73 790.59 1050.6 495.75"></polygon>
<text class="attp-cls-5" transform="translate(518.59 1002.94)"><tspan class="attp-cls-8" x="0" y="0">A</tspan><tspan class="attp-cls-3" x="123.59" y="0">T</tspan><tspan class="attp-cls-6" x="267.75" y="0">TI</tspan><tspan class="attp-cls-7" x="498.09" y="0">R</tspan><tspan class="attp-cls-6" x="640.38" y="0">E</tspan></text>
<rect class="attp-cls-2" height="1150" width="1765" x="10" y="10"></rect>
</svg>
<span class="page-eyebrow">House of AM</span>
<h1>Luxury Streetwear</h1>
<span class="page-hero-sub">Defined by identity. Not trends.</span>
</div>
</section>
<div class="closing-cta"><p>Please Visit Our Store</p><p style="margin-top:.5rem"><a href="https://www.google.com/maps/dir/?api=1&amp;destination=329+High+Road+Harrow+HA3+5EQ" rel="noopener" style="color:var(--gold);font-family:var(--ff-body);font-size:9px;letter-spacing:.25em;text-transform:uppercase;font-weight:600;border-bottom:1px solid var(--gold);padding-bottom:2px" target="_blank">329 High Road, Harrow, HA3 5EQ</a></p></div>
</div>
<!-- ═══ ABOUT ═══ -->
<div class="page" id="page-about">
<!-- Hero -->
<section class="ab-hero">
<span class="ab-eyebrow">The Beginning</span>
<h1>It started with a <em>passion.</em> Not a plan.</h1>
<hr class="ab-rule"/>
</section>
<!-- Origin -->
<section class="ab-origin">
<div class="shell">
<span class="ab-eyebrow">The Beginning</span>
<p>AM didn't begin as a business strategy. It began as a conviction — that grooming deserved to be taken seriously. That the men who sat in the chair deserved more than a quick cut and a handshake. They deserved an experience that reflected the standard they held themselves to.</p>
<p>From the first day the doors opened on Harrow High Road, one thing was non-negotiable: quality over quantity. Every client. Every cut. Every time. That wasn't a tagline. It was the only way to operate.</p>
<p>What started as a barber lounge became something nobody expected — including its founder. Within two years, it had outgrown its original identity and become the foundation of something much larger.</p>
</div>
</section>
<!-- Quote -->
<section class="ab-quote">
<div class="shell">
<blockquote>The industry had settled. Everyone accepted average as normal. I couldn't. I wouldn't. So I built what I couldn't find anywhere else.</blockquote>
<cite>Founder, House of AM</cite>
</div>
</section>
<!-- Philosophy -->
<section class="ab-philosophy">
<div class="shell">
<div class="head">
<span class="ab-eyebrow">The Philosophy</span>
<h2 class="reveal">Most businesses chase clients. We set a <em>standard</em> and let it speak.</h2>
</div>
<div class="principles">
<div class="principle">
<div class="num">01</div>
<div><h3>Standard over volume</h3><p>We turn people away before we compromise what we have built. A full book at the right standard is worth more than a full building at the wrong one.</p></div>
</div>
<div class="principle">
<div class="num">02</div>
<div><h3>Premium always</h3><p>Every decision — pricing, hiring, design, product — is made through one lens. Does it increase the standard or dilute it? There is no middle ground.</p></div>
</div>
<div class="principle">
<div class="num">03</div>
<div><h3>Built to last</h3><p>We are not building a trend. We are building a house. Something with weight, with permanence, with a standard that outlasts any moment or movement.</p></div>
</div>
</div>
</div>
</section>
<!-- Why it exists -->
<section class="ab-why">
<div class="shell">
<span class="ab-eyebrow">Why it exists</span>
<h2>The industry had an average problem. <em>AM is the answer.</em></h2>
<p>The industry settled. Barbershops became interchangeable. Walk in, sit down, walk out. No consistency, no standard, no experience worth remembering.</p>
<p>We refused to. AM Barber Lounge was built to prove that luxury grooming was not reserved for central London or five-star hotel spas. It could exist right here — in Harrow, on the High Road, for the men who demand more.</p>
<p>Then we went further. Grooming was just the beginning. Recovery. Products. Identity. House of AM was inevitable.</p>
</div>
</section>
<!-- The House -->
<section class="ab-house">
<div class="shell">
<div class="head">
<span class="ab-eyebrow">The House</span>
<h2>Four disciplines. <em>One standard.</em></h2>
</div>
<div class="disciplines">
<div class="discipline">
<p class="disc-label">AM Barber Lounge · Grooming</p>
<div>
<h3>Where it began.</h3>
<p>Precision grooming at a standard the industry was not offering. Fully booked. Uncompromising.</p>
<button class="disc-more" data-nav="barber-lounge">Enter the Lounge</button>
</div>
</div>
<div class="discipline">
<p class="disc-label">AM Renovair · Recovery</p>
<div>
<h3>Rebuild. Recharge.</h3>
<p>The recovery studio built for those who understand that how you feel is as important as how you look.</p>
<button class="disc-more" data-nav="renovair">Enter Renovair</button>
</div>
</div>
<div class="discipline">
<p class="disc-label">AM Essence · Products</p>
<div>
<h3>Built for daily use.</h3>
<p>Premium grooming products made in the UK. Built for the AM standard. Not for shelves — for the men who use them daily.</p>
<button class="disc-more" data-nav="essence">Enter Essence</button>
</div>
</div>
<div class="discipline">
<p class="disc-label">AM Attire · Fashion</p>
<div>
<h3>Identity. Not trends.</h3>
<p>Luxury streetwear defined by identity, not trends. This is not merch. This is a clothing brand built to stand alone.</p>
<button class="disc-more" data-nav="attire">Enter Attire</button>
</div>
</div>
</div>
</div>
</section>
<!-- Close -->
<section class="ab-close">
<h2>The House exists for those who choose differently.</h2>
<p class="sub">Defined by standards. Not routine.</p>
<p class="body-text">You don't stumble into AM. You choose it. Because you understand that the standard you hold in every other area of your life deserves to be reflected in how you present yourself, how you recover, what you wear, what you use.</p>
</section>
<div class="closing-cta"><p>Your Standard Starts Here.</p></div>
</div><!-- end page-about -->
<!-- FOOTER -->


<?php get_footer(); ?>