<?php
/**
 * House of AM — functions.php
 * Enqueues all styles and scripts preserved from commit 16c8bc5a
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'HOA_VERSION', '1.1' );
define( 'HOA_URI', get_template_directory_uri() );

/* ── Theme setup ── */
function hoa_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo' );
	add_theme_support( 'woocommerce' );

	register_nav_menus( array(
		'primary' => __( 'Primary Navigation', 'houseofam' ),
		'footer'  => __( 'Footer Navigation', 'houseofam' ),
	) );
}
add_action( 'after_setup_theme', 'hoa_setup' );

/* ── Enqueue styles & scripts ── */
function hoa_enqueue() {
	// Google Fonts — same as original
	wp_enqueue_style(
		'hoa-fonts',
		'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500;1,600&family=Cormorant+SC:wght@500;600;700&family=Josefin+Sans:wght@300;400;600&family=GFS+Didot&display=swap',
		array(),
		null
	);

	// Main theme stylesheet (all inline CSS from original)
	wp_enqueue_style(
		'houseofam-style',
		get_stylesheet_uri(),
		array( 'hoa-fonts' ),
		HOA_VERSION
	);

	// Main JS (all inline JS from original — loader, cursor, SPA router, transitions)
	wp_enqueue_script(
		'houseofam-main',
		HOA_URI . '/assets/js/main.js',
		array(),
		HOA_VERSION,
		true // load in footer
	);
}
add_action( 'wp_enqueue_scripts', 'hoa_enqueue' );

/* ── Body class ── */
function hoa_body_classes( $classes ) {
	$classes[] = 'hoa-wp';
	return $classes;
}
add_filter( 'body_class', 'hoa_body_classes' );

/* ── Skip link ── */
function hoa_skip_link() {
	echo '<a class="skip-link screen-reader-text" href="#main">Skip to content</a>';
}
add_action( 'wp_body_open', 'hoa_skip_link' );

/* ── Remove WP admin bar push ── */
add_action( 'get_header', function() {
	remove_action( 'wp_head', '_admin_bar_bump_cb' );
} );
