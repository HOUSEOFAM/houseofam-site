/* House of AM — main.js | Preserved from commit 16c8bc5a */

(function(){
  var loader=document.getElementById('loader');
  setTimeout(function(){loader.classList.add('done');},3200);
  setTimeout(function(){loader.style.display='none';},4100);

  var header=document.getElementById('siteHeader');
  window.addEventListener('scroll',function(){header.classList.toggle('scrolled',window.scrollY>8);},{passive:true});

  var toggle=document.getElementById('menuToggle');
  var navList=document.getElementById('navList');
  toggle.addEventListener('click',function(){
    var open=toggle.getAttribute('aria-expanded')==='true';
    toggle.setAttribute('aria-expanded',String(!open));
    navList.classList.toggle('open',!open);
    document.body.style.overflow=open?'':'hidden';
  });
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){toggle.setAttribute('aria-expanded','false');navList.classList.remove('open');document.body.style.overflow='';}
  });

  var PAGES=['home','barber-lounge','renovair','essence','attire','about'];
  var currentPage='home';
  var transition=document.getElementById('pageTransition');
  var transBar=document.getElementById('transitionBar');

  var transitioning = false;
  var ptEl = document.getElementById('pageTransition');

  // Build transition overlay entirely in JS — WordPress-proof
  (function(){
    if(!ptEl) return;
    ptEl.style.cssText = 'position:fixed;inset:0;z-index:99998;pointer-events:none!important;background:#1a1714;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;opacity:0;transition:opacity 0s';
    ptEl.innerHTML =
      '<svg id="ptSvg" style="width:min(220px,55vw);height:auto" viewBox="200 130 1520 680" xmlns="http://www.w3.org/2000/svg">' +
        '<defs>' +
          '<linearGradient id="ptGA" x1="963" y1="167" x2="956" y2="737" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#C8C8C8"/><stop offset="1" stop-color="#909090"/></linearGradient>' +
          '<linearGradient id="ptGB" x1="694" y1="632" x2="1225" y2="632" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#DDC18E"/><stop offset="1" stop-color="#B1915D"/></linearGradient>' +
        '</defs>' +
        '<polygon fill="url(#ptGA)" points="960,260 1033,463 1109,463 1083,390 998,156 960,156 959,156 921,156 836,390 810,463 886,463"/>' +
        '<polygon fill="url(#ptGB)" points="1118,485 1117,484 1041,484 1041,485 960,675 878,485 878,484 802,484 801,485 694,780 771,780 843,580 929,780 959,780 960,780 990,780 1076,580 1148,780 1225,780"/>' +
      '</svg>' +
      '<div style="width:min(260px,60vw);height:1.5px;background:rgba(184,146,42,.18);border-radius:1px;overflow:hidden">' +
        '<div id="ptBar" style="height:100%;width:0;background:linear-gradient(90deg,#8a6d1c,#b8922a,#d4b158);border-radius:1px;transition:none"></div>' +
      '</div>' +
      '<span style="font-family:var(--ff-body,sans-serif);font-size:11px;letter-spacing:.38em;text-transform:uppercase;color:#8a8178;font-weight:600">House of AM</span>';
  })();

  function showPage(id, scrollTarget, skipTransition){
    if((id === currentPage && !scrollTarget) || transitioning){ return; }

    // Direct swap — no transition (used on initial load)
    if(skipTransition || !ptEl){
      PAGES.forEach(function(p){ var el=document.getElementById('page-'+p); if(el) el.classList.remove('active'); });
      var t=document.getElementById('page-'+id);
      if(t){ t.classList.add('active'); currentPage=id; window.scrollTo(0,0); }
      document.querySelectorAll('[data-nav]').forEach(function(a){
        a.classList.toggle('active', a.getAttribute('data-nav')===id && !a.getAttribute('data-scroll'));
      });
      return;
    }

    transitioning = true;

    var bar = document.getElementById('ptBar');
    var svg = document.getElementById('ptSvg');

    if(bar){ bar.style.transition='none'; bar.style.width='0'; }
    if(svg){ svg.style.animation='none'; }

    // Phase 1: FADE IN
    ptEl.style.transition = 'opacity 0s';
    ptEl.style.opacity = '0';
    ptEl.style.setProperty('pointer-events','all','important');
    void ptEl.offsetWidth;
    ptEl.style.transition = 'opacity .55s ease';
    ptEl.style.opacity = '1';

    setTimeout(function(){
      if(svg){ svg.style.animation = 'pulseGold 2.4s ease-in-out infinite'; }
      if(bar){ void bar.offsetWidth; bar.style.transition='width 1.4s ease-in-out'; bar.style.width='100%'; }

      PAGES.forEach(function(p){ var el=document.getElementById('page-'+p); if(el) el.classList.remove('active'); });
      var target=document.getElementById('page-'+id);
      if(target){ target.classList.add('active'); currentPage=id; window.scrollTo(0,0); }
      document.querySelectorAll('[data-nav]').forEach(function(a){
        a.classList.toggle('active', a.getAttribute('data-nav')===id && !a.getAttribute('data-scroll'));
      });
      navList.classList.remove('open');
      if(typeof toggle!=='undefined'){ toggle.setAttribute('aria-expanded','false'); }
      document.body.style.overflow='';
      document.documentElement.style.overflow='';
      document.documentElement.style.height='auto';
      document.body.style.height='auto';

      // Phase 3: FADE OUT
      setTimeout(function(){
        if(svg){ svg.style.animation='none'; }
        ptEl.style.transition = 'opacity .6s ease';
        ptEl.style.opacity = '0';
        setTimeout(function(){
          ptEl.style.setProperty('pointer-events','none','important');
          if(bar){ bar.style.transition='none'; bar.style.width='0'; }
          transitioning=false;
          if(scrollTarget){ var el=document.getElementById(scrollTarget); if(el) el.scrollIntoView({behavior:'smooth'}); }
        }, 640);
      }, 1550);

    }, 580);
  }

  document.addEventListener('click',function(e){
    var el=e.target.closest('[data-nav]');
    if(!el){return;}
    e.preventDefault();
    showPage(el.getAttribute('data-nav'),el.getAttribute('data-scroll'));
  });

  showPage('home', null, true);

  /* ══════════════════════════════════════════
     HOUSE OF AM — WORLD CLASS ENHANCEMENTS
     Injected inside main IIFE — WordPress-proof
     ══════════════════════════════════════════ */
  (function initEnhancements(){
    var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

    /* ── OVERLAYS: never block clicks ── */
    function lockOverlays(){
      ['pageTransition','bookingModal'].forEach(function(id){
        var el=document.getElementById(id);
        if(el&&!el.classList.contains('open')&&!el.classList.contains('pt-in')&&!el.classList.contains('pt-hold')){
          el.style.setProperty('pointer-events','none','important');
        }
      });
    }
    lockOverlays();
    setInterval(lockOverlays,800);

    /* ── HERO H1: word-by-word stagger ── */
    var h1=document.getElementById('heroH1');
    if(h1){
      h1.style.opacity='1'; h1.style.transform='none';
      var raw=h1.innerHTML;
      var parts=raw.split(/(<br>|<em>[\s\S]*?<\/em>|\s+)/);
      var out='',dl=0.45;
      parts.forEach(function(p){
        if(!p)return;
        if(p==='<br>'||/^\s+$/.test(p)){out+=p;return;}
        if(p.indexOf('<em>')===0){
          out+='<em style="display:inline-block;opacity:0;transform:translateY(52px) skewX(-5deg);transition:opacity .7s ease '+dl+'s,transform .9s cubic-bezier(.23,1,.32,1) '+dl+'s;color:#d4b158;font-style:italic">'+p.replace(/<\/?em>/g,'')+'</em>';
        } else {
          out+='<span style="display:inline-block;opacity:0;transform:translateY(52px) skewX(-5deg);transition:opacity .7s ease '+dl+'s,transform .9s cubic-bezier(.23,1,.32,1) '+dl+'s">'+p+'</span>';
        }
        dl+=0.068;
      });
      h1.innerHTML=out;
      setTimeout(function(){
        h1.querySelectorAll('span,em').forEach(function(el){el.style.opacity='1';el.style.transform='translateY(0) skewX(0)';});
      },500);
    }

    /* ── REVEAL: show all elements immediately, no opacity tricks ── */
    document.querySelectorAll('.page').forEach(function(page){
      page.querySelectorAll('h1,h2,h3,h4,h5,p,div,span,section').forEach(function(el){
        el.style.opacity = '';
        el.style.transform = '';
        el.style.transition = '';
        delete el.dataset.amR;
        delete el.dataset.amRevealed;
      });
    });

    /* ── SHIMMER on every button ── */
    function applyShimmer(){
      document.querySelectorAll('.btn-gold,.door-cta,.btn-solid,.disc-more').forEach(function(btn){
        if(btn.dataset.shimmer)return;
        btn.dataset.shimmer='1';
        btn.style.overflow='hidden'; btn.style.position='relative';
        var sh=document.createElement('span');
        sh.style.cssText='position:absolute;top:0;left:0;width:50px;height:100%;background:linear-gradient(105deg,transparent,rgba(255,255,255,.38),transparent);transform:translateX(-80px) skewX(-12deg);pointer-events:none;z-index:10';
        btn.appendChild(sh);
        btn.addEventListener('mouseenter',function(){
          sh.style.transition='transform .5s ease';
          sh.style.transform='translateX('+(btn.offsetWidth+80)+'px) skewX(-12deg)';
          setTimeout(function(){sh.style.transition='none';sh.style.transform='translateX(-80px) skewX(-12deg)';},520);
        });
      });
    }
    applyShimmer();
    setInterval(applyShimmer,1500);

    /* ── DOOR PARALLAX ── */
    if(!isTouch){
      function initParallax(){
        document.querySelectorAll('.door').forEach(function(door){
          if(door.dataset.px)return;
          door.dataset.px='1';
          var logo=door.querySelector('.door-logo');
          var cont=door.querySelector('.door-content');
          door.addEventListener('mousemove',function(e){
            var r=door.getBoundingClientRect();
            var x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
            if(logo)logo.style.transform='translate('+(x*26)+'px,'+(y*18)+'px)';
            if(cont)cont.style.transform='translate('+(x*-7)+'px,'+(y*-5)+'px)';
          });
          door.addEventListener('mouseleave',function(){
            [logo,cont].forEach(function(el){
              if(!el)return;
              el.style.transition='transform .9s cubic-bezier(.23,1,.32,1)';
              el.style.transform='none';
              setTimeout(function(){el.style.transition='';},950);
            });
          });
        });
      }
      initParallax();
      setInterval(initParallax,2000);
    }

    /* ── ROTATING CURSOR — always visible, always spinning ── */
    if(!isTouch){
      // Remove any old cursor elements
      ['cursorRing','cursorRingNew','amCursorRing'].forEach(function(id){
        var e=document.getElementById(id);if(e)e.remove();
      });
      // Remove old dot
      var oldDot=document.getElementById('cursorDot');
      if(oldDot)oldDot.remove();

      // Build dot
      var dot=document.createElement('div');
      dot.id='cursorDot';
      dot.style.cssText='position:fixed;top:-100px;left:-100px;width:8px;height:8px;background:#c69c6d;border-radius:50%;pointer-events:none!important;z-index:100002;transform:translate(-50%,-50%);transition:width .2s,height .2s,background .2s;will-change:left,top';
      document.body.appendChild(dot);

      // Build SVG ring
      var NS='http://www.w3.org/2000/svg';
      var svg=document.createElementNS(NS,'svg');
      svg.id='amCursorRing';
      svg.setAttribute('viewBox','-44 -44 88 88');
      svg.setAttribute('width','88');svg.setAttribute('height','88');
      svg.style.cssText='position:fixed;top:-300px;left:-300px;pointer-events:none!important;z-index:100001;will-change:transform';
      var sd=document.createElementNS(NS,'defs');
      var sp=document.createElementNS(NS,'path');
      sp.id='amTp';
      sp.setAttribute('d','M 0 0 m -26 0 a 26 26 0 1 1 52 0 a 26 26 0 1 1 -52 0');
      sd.appendChild(sp);svg.appendChild(sd);
      var sc=document.createElementNS(NS,'circle');
      sc.setAttribute('r','26');sc.setAttribute('fill','none');
      sc.setAttribute('stroke','rgba(198,156,109,.42)');sc.setAttribute('stroke-width','1.2');
      svg.appendChild(sc);
      var st=document.createElementNS(NS,'text');
      st.style.cssText='font-family:Arial,sans-serif;font-size:4.8px;letter-spacing:2.5px;font-weight:700;fill:rgba(198,156,109,.6);text-transform:uppercase';
      var stp=document.createElementNS(NS,'textPath');
      stp.setAttribute('href','#amTp');stp.setAttribute('startOffset','0%');
      stp.textContent='EXPERIENCE · HOUSE OF AM · ';
      st.appendChild(stp);svg.appendChild(st);
      document.body.appendChild(svg);

      var mx=0,my=0,rx=0,ry=0,ang=0,hov=false,entered=false;
      document.addEventListener('mousemove',function(e){
        mx=e.clientX;my=e.clientY;
        if(!entered){
          entered=true;
          svg.style.top='0';svg.style.left='0';
          dot.style.top='0';dot.style.left='0';
        }
      });

      (function frame(){
        rx+=(mx-rx)*.12;ry+=(my-ry)*.12;
        dot.style.left=mx+'px';dot.style.top=my+'px';
        svg.style.transform='translate(calc('+rx+'px - 50%),calc('+ry+'px - 50%)) rotate('+ang+'deg)';
        ang+=hov?1.2:0.38;
        requestAnimationFrame(frame);
      })();

      document.addEventListener('mouseover',function(e){
        var t=e.target.closest('a,button,.door,.door-cta,.btn-gold,.btn-solid,.disc-more,.nav-links a,.logo-lockup,.pricing-card,.addl-card,.pillar,.principle');
        if(t){
          hov=true;
          sc.setAttribute('stroke','rgba(198,156,109,.95)');sc.setAttribute('r','32');
          st.style.fill='rgba(198,156,109,1)';st.style.fontSize='5.4px';
          dot.style.width='4px';dot.style.height='4px';dot.style.background='#c8a96e';
        } else {
          hov=false;
          sc.setAttribute('stroke','rgba(198,156,109,.42)');sc.setAttribute('r','26');
          st.style.fill='rgba(198,156,109,.6)';st.style.fontSize='4.8px';
          dot.style.width='8px';dot.style.height='8px';dot.style.background='#c69c6d';
        }
      });
    }

    /* ── DOORS: always clickable ── */
    function fixClicks(){
      document.querySelectorAll('.door-cta,.door,.btn-gold').forEach(function(el){
        el.style.setProperty('position','relative','important');
        el.style.setProperty('z-index','10','important');
      });
      lockOverlays();
    }
    fixClicks();
    setInterval(fixClicks,1000);

  })(); /* end initEnhancements */

})();



// Override WordPress body height collapse
(function(){
  function fixBody(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('overflow-y','scroll','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
  }
  fixBody();
  document.addEventListener('DOMContentLoaded', fixBody);
  window.addEventListener('load', fixBody);
  var t=0;
  var iv=setInterval(function(){ fixBody(); t++; if(t>6) clearInterval(iv); },500);
})();
