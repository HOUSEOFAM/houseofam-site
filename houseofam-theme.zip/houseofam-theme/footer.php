<?php
/**
 * House of AM — footer.php
 * Preserved from commit 16c8bc5a
 */
?>

<footer class="site-footer">
<div class="footer-brand"><div class="footer-brand-wrap"><span class="footer-brand-line"></span><span class="footer-brand-name">House of AM</span><span class="footer-brand-line"></span></div></div>
<nav><ul class="footer-nav">
<li><a data-nav="home">Home</a></li>
<li><a data-nav="about">About</a></li>
<li><a data-nav="barber-lounge">Barber Lounge</a></li>
<li><a data-nav="renovair">Renovair</a></li>
<li><a data-nav="essence">Essence</a></li>
<li><a data-nav="attire">Attire</a></li>
<li><a href="tel:02083789463">Contact</a></li>
</ul></nav>
<address class="footer-addr">329 High Road, Harrow, HA3 5EQ</address>
<p class="footer-legal">© 2026 House of AM. All rights reserved.</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>